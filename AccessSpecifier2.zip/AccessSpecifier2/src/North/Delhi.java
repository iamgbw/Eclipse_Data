package North;

public class Delhi {
	
	public int a = 10 ;		
		   int b = 20 ;
	protected int c = 30 ;
	private int d = 40;
		
	public static void main(String[] args) {
		
		Delhi g = new Delhi(); 
		
		System.out.println(g.a);	// public
		System.out.println(g.b);	// default
		System.out.println(g.c);	// protected
		System.out.println(g.d);	// private
		
		
	}

}
