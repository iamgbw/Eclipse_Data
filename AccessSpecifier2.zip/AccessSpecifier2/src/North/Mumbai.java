package North;

public class Mumbai {

public static void main(String[] args) {
		
		Delhi g = new Delhi(); 
		Mumbai m = new Mumbai();
		
		System.out.println(g.a);	// public
		System.out.println(g.b);	// default
		System.out.println(g.c);	// protected
		//System.out.println(g.d);	// private
		
		/* It's an Inheritance concept, we can't call delhi class 
		 property by using mumbai class without inheritance */
		
//		System.out.println(m.a);	// public
//		System.out.println(m.b);	// default
//		System.out.println(m.c);	// protected
		//System.out.println(m.d);	// private
		
		
	}

}
