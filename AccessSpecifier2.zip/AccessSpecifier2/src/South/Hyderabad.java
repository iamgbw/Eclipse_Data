package South;

import North.Delhi;

public class Hyderabad {
	
public static void main(String[] args) {
		
		Delhi g = new Delhi(); 
		
		System.out.println(g.a);	// public
		//System.out.println(g.b);	// default
	    // System.out.println(g.c);	// protected
		//System.out.println(g.d);	// private

	}

}
