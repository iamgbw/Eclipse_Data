package South;

import North.Delhi;

public class Bengaluru extends Delhi {
	
public static void main(String[] args) {
		
	Bengaluru n = new Bengaluru(); 
		
		System.out.println(n.a);	// public
		//System.out.println(g.b);	// default
	    System.out.println(n.c);	// protected
		//System.out.println(g.d);	// private
		
		
	}

}
