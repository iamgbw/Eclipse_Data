package ThisAndSuper;

public class Mumbai {

	// Global variable of super class 
	// with Same Name
	
	public static int a = 789;
		   public int b = 250;
}
