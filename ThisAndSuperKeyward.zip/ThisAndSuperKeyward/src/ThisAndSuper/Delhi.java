package ThisAndSuper;

public class Delhi extends Mumbai {

	public static int a = 45;  	// Global + static
		   public int b = 10;  	// Global + Non Static
		   
	public void test () 
	{
		int a = 75; 	// Local
		int b = 65; 	// Local
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(Delhi.a);
		//System.out.println(this.a);
		System.out.println(this.b);
		
		System.out.println("--------");
		System.out.println(Mumbai.a);
		//System.out.println(super.a);	// Super Class Variable
		System.out.println(super.b); 	// Super Class Variable
	}
	
	public static void main(String[] args) {
		
		Delhi d = new Delhi ();
		d.test();
	}
}
