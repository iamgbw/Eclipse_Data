package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pom.ApplicationHeaderPage;
import pom.LoginPage;

public class VerifyApplicationHeaderPageWebElements {
	
	private WebDriver driver;
	private ApplicationHeaderPage applicationHeaderPage;
	private LoginPage loginPage;
	private SoftAssert soft;
	
	@BeforeClass
	public void launchBrowser() {
		System.out.println("Launch Browser");
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	// Implicit Wait
	}
	
	
	@BeforeMethod
	public void loginToApplication() {
		System.out.println("Login To Application");
		driver.get("http://localhost/login.do");
		loginPage = new LoginPage(driver);
		applicationHeaderPage = new ApplicationHeaderPage (driver);
		loginPage.sendUserName();
		loginPage.sendPassword();
		loginPage.clickOnKeepMeLoginCheckBox();
		loginPage.clickOnLogIn();
	}
	
	@Test (priority = 2)
	public void verifyTasksTab() {
		soft = new SoftAssert();
		System.out.println("Verify Tasks Tab");
		
		applicationHeaderPage.clickOnTasks();
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("+" + title + "+" );
		
		Assert.assertEquals(url, "http://localhost/tasks/otasklist.do");
		
		soft.assertEquals(title, "actiTIME - Open Tasks");
		soft.assertAll();
	}
	
	@Test (priority = 4)
	public void verifyUserTab() {
		soft = new SoftAssert();
		System.out.println("Verify User Tab");
		applicationHeaderPage.clickOnUsers();
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("+" + title + "+" );
		
		
		Assert.assertEquals(url, "http://localhost/administration/userlist.do");
		
		soft.assertEquals(title, "actiTIME - User List");
		soft.assertAll();
	}
	
	@Test (priority = 1)
	public void verifyTimeTrack() {
		soft = new SoftAssert();
		System.out.println("Verify Time Track");
		applicationHeaderPage.clickOnTimeTrack();
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("+" + title + "+" );
		
		
		Assert.assertEquals(url, "http://localhost/user/submit_tt.do");
		
		soft.assertEquals(title, "actiTIME - Enter Time-Track");
		soft.assertAll();
	}
	
	@Test (priority = 3)
	public void verifyReports() {
		soft = new SoftAssert();
		System.out.println("Verify Reports");
		applicationHeaderPage.clickOnReports();
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("+" + title + "+" );
		
		
		Assert.assertEquals(url, "http://localhost/reports/reports.do");
		
		soft.assertEquals(title, "actiTIME - Saved Reports");
		soft.assertAll();
	}
	
	@Test (priority = 5)
	public void verifyWorkShedule() {
		soft = new SoftAssert();
		System.out.println("Verify Work Shedule");
		applicationHeaderPage.clickOnWorkShedule();
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("+" + title + "+" );
		
		
		Assert.assertEquals(url, "http://localhost/administration/workingdays.do");
		
		soft.assertEquals(title, "actiTIME - Corporate Schedule");
		soft.assertAll();
	}
	
	@AfterMethod
	public void logout() {
		System.out.println("LogOut");
		applicationHeaderPage.clickOnLogout();
		System.out.println("-------------------------------");
	}
	
	@AfterClass
	public void closeBrowser() {
		System.out.println("Close Browser");
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public static void main(String[] args) {
//		
//		System.setProperty("webdriver.chrome.driver", 
//				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
//		
//		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	// Implicit Wait
//		
//		driver.get("http://localhost/login.do");
//		
//		
//		LoginPage loginPage = new LoginPage(driver);
//		loginPage.sendUserName();
//		loginPage.sendPassword();
//		loginPage.clickOnKeepMeLoginCheckBox();
//		loginPage.clickOnLogIn();
//		
//		
//		ApplicationHeaderPage applicationHeaderPage = new ApplicationHeaderPage(driver);
//		applicationHeaderPage.clickOnTasks();
//		String url = driver.getCurrentUrl();
//		String title = driver.getTitle();
//		
//		if(url.equals("http://localhost/tasks/otasklist.do"))
//		{
//			System.out.println("Pass");
//		}
//		else
//		{
//			System.out.println("Fail");
//		}
//		
//		if(title.equals("Open Tasks"))
//		{
//			System.out.println("Pass");
//		}
//		else
//		{
//			System.out.println("Fail");
//		}		
//	}
	
}
