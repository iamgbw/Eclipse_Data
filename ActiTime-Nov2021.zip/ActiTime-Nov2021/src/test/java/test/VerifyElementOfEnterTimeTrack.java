package test;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pom.ApplicationHeaderPage;
import pom.EnterTimeTrack;
import pom.LoginPage;

public class VerifyElementOfEnterTimeTrack {

	private WebDriver driver;
	private ApplicationHeaderPage applicationHeaderPage;
	private LoginPage loginPage;
	private EnterTimeTrack enterTimeTrack;
	private SoftAssert soft;
	
	@BeforeClass
	public void launchBrowser() {
		System.out.println("Launch Browser");
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	// Implicit Wait
	}
	
	@BeforeMethod
	public void loginToApplication() 
	{
		System.out.println("Login To Application");
		driver.get("http://localhost/login.do");
		loginPage = new LoginPage(driver);
		loginPage.sendUserName();
		loginPage.sendPassword();
		loginPage.clickOnKeepMeLoginCheckBox();
		loginPage.clickOnLogIn();
		applicationHeaderPage = new ApplicationHeaderPage (driver);
		applicationHeaderPage.clickOnTasks();
		enterTimeTrack = new EnterTimeTrack(driver);
		
	}
	
	@Test (priority = 1)
	public void checkTextOfBoxCustomer()  
	{
		soft = new SoftAssert();
		String customer = enterTimeTrack.getTextFromBoxCustomer();
		soft.assertEquals(customer, "Customer");
		soft.assertAll();
	}
	
	@Test(priority = 2)
	public void getTextFromBoxProject() 
	{
		soft = new SoftAssert();
		String project = enterTimeTrack.getTextFromBoxProject();
		soft.assertEquals(project, "Project");
		soft.assertAll();
	}
	
	@Test (priority = 3)
	public void getTextFromTask() 
	{
		soft = new SoftAssert();
		String task = enterTimeTrack.getTextFromBoxTask();
		soft.assertEquals(task, "Task");
		soft.assertAll();
	}
	
	@Test (priority = 4)
	public void checkTextOfBoxDeadline()  
	{
		soft = new SoftAssert();
		String deadline = enterTimeTrack.getTextFromBoxDeadline();
		soft.assertEquals(deadline, "Deadline");
		soft.assertAll();
	}
	
	@Test (priority = 5)
	public void getTextFromBoxTimeTrackSummary() 
	{
		soft = new SoftAssert();
		String timeTrackSummary = enterTimeTrack.getTextFromBoxTimeTrackSummary();
		soft.assertEquals(timeTrackSummary, "Time-Track Summary");
		soft.assertAll();
	}
	
//	@Test (priority = 6)
//	public void getTextFromBoxLastTrackingDate() 
//	{
//		soft = new SoftAssert();
//		String lastTrackingDate = enterTimeTrack.getTextFromBoxLastTrackingDate();
//		
//		soft.assertEquals(lastTrackingDate, "Last Tracking\r\n"
//				+ "Date");
//		soft.assertAll();
//	}
//	
//	@Test (priority = 7)
//	public void getTextFromBoxSpentDate() 
//	{
//		soft = new SoftAssert();
//		String spentDate = enterTimeTrack.getTextFromBoxSpentDate();
//		soft.assertEquals(spentDate, "Spent\r\n"
//				+ "Time");
//		soft.assertAll();
//	}
	
	@AfterMethod
	public void logout() {
		System.out.println("LogOut");
		System.out.println("------------------------------------");
		applicationHeaderPage.clickOnLogout();
	}
	
	@AfterClass
	public void closeBrowser() {
		System.out.println("Close Browser");
		driver.quit();
	}
}
