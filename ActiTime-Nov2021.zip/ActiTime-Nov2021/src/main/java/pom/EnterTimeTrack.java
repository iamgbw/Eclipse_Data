package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EnterTimeTrack {

	@FindBy (xpath = "(//th[@nowrap='1'])[1]" )
	private WebElement boxCustomer;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[2]" )
	private WebElement boxProject;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[3]" )
	private WebElement boxTask;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[4]" )
	private WebElement boxDeadline;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[5]" )
	private WebElement boxTimeTrackSummary;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[6]" )
	private WebElement boxLastTrackingDate;
	
	@FindBy (xpath = "(//th[@nowrap='1'])[7]" )
	private WebElement boxSpentDate;
	
	public EnterTimeTrack (WebDriver driver)
	{
		PageFactory.initElements(driver, this);	
	}
	
	public String getTextFromBoxCustomer() 
	{
		String customer = boxCustomer.getText();
		System.out.println(customer);
		return customer;
	}
	
	public String getTextFromBoxProject()
	{
		String project = boxProject.getText();
		System.out.println(project);
		return project;
	}
	
	public String getTextFromBoxTask()
	{
		String task = boxTask.getText();
		System.out.println(task);
		return task;
	}
	
	public String getTextFromBoxDeadline()
	{
		String deadline = boxDeadline.getText();
		System.out.println(deadline);
		return deadline;
	}
	
	public String getTextFromBoxTimeTrackSummary()
	{
		String timeTrackSummary = boxTimeTrackSummary.getText();
		System.out.println(timeTrackSummary);
		return timeTrackSummary;
	}
	
	public String getTextFromBoxLastTrackingDate()
	{
		String lastTrackingDate = boxLastTrackingDate.getText();
		System.out.println(lastTrackingDate);
		return lastTrackingDate;
	}
	
	public String getTextFromBoxSpentDate()
	{
		String spentDate = boxSpentDate.getText();
		System.out.println(spentDate);
		return spentDate;
	}	
}
