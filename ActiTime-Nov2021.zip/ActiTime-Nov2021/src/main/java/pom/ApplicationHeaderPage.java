package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicationHeaderPage {
	
	@FindBy (xpath = "(//td[@class='navItem relative'])[1]" )
	private WebElement timeTrack;
	
	@FindBy (xpath = "(//td[@class='navItem relative'])[2]" )
	private WebElement tasks;
	
	@FindBy (xpath = "(//td[@class='navItem relative'])[3]" )
	private WebElement reports;
	
	@FindBy (xpath = "(//td[@class='navItem relative'])[4]" )
	private WebElement users;
	
	@FindBy (xpath = "(//td[@class='navItem relative'])[5]" )
	private WebElement workShedule;
	
	@FindBy (xpath = "//a[@id='logoutLink']" )
	private WebElement logout;
	
	@FindBy (xpath = "(//div[@class='popup_menu_center'])[3]" )
	private WebElement helpAndSupport;

	@FindBy (xpath = "(//li[@class='popup_menu_item'])[9]" )
	private WebElement userGuide;
	
	@FindBy (xpath = "(//li[@class='popup_menu_item'])[10]" )
	private WebElement fAQ;
	
	public ApplicationHeaderPage (WebDriver driver)
	{
		PageFactory.initElements(driver, this);	
	}
	
	public void clickOnTimeTrack()
	{
		timeTrack.click();
	}
	
	public void clickOnTasks()
	{
		tasks.click();
	}
	
	public void clickOnReports()
	{
		reports.click();
	}
	
	public void clickOnUsers()
	{
		users.click();
	}
	
	public void clickOnWorkShedule()
	{
		workShedule.click();
	}
	
	public void clickOnLogout()
	{
		logout.click();
	}
	
	public void clickOnUserGuide()
	{
		userGuide.click();
	}
	
	public void frequentlyAskedQuestion()
	{
		fAQ.click();
	}
}
