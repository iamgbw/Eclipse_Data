package demo;

public class Mumbai {
	
			  static int a=10;
			   int b;
			   int e;
		Mumbai()
		{
			e=58;
			b=49;	
		}
		
		Mumbai(int g)
		{
			a=90;
			b=63;	
		}
		
		Mumbai(int h, char d)
		{
			a= 36;
			b= 47;
		}
		
		public static void main(String[]args)
		
		{
			System.out.println(a);
			
			Mumbai x = new Mumbai();
			
			System.out.println(x.e);
			System.out.println(x.b);
			Mumbai y = new Mumbai(111);
			
			
			System.out.println(x.e);
			
			Mumbai z = new Mumbai(12,'$');
			
			System.out.println(y.b);
			System.out.println(z.b);
		
			
			
			System.out.println(y.b);
			
			System.out.println(x.a);
			System.out.println(y.a);
				
			
			
			System.out.println(y.b);
			
		}
		
	}


