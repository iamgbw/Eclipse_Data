package demo;

public class Satara3 {
	static int a=10;
    int b=70;
    
    void demo (int a)
    {
    	System.out.println("C V Raman");
    	System.out.println("Albart");
    	System.out.println("Ramanujan");
    }
    
    void demo (char v)
    {
    	System.out.println("Suyash");
    	System.out.println("Sachin");
    	System.out.println("Nagoba");
    }
	   
    	//satara3()
    	//{
	 
    	//	 }
    	//System.out.println(s.b);
	          
Satara3 ()
{
	 a=63;   //local
	 b=90;
}

Satara3(char d,char t)
{
	int b=100;	//local
}	   

public static void main(String[]args)
{
	
	//satara3 s=new satara3();

	//System.out.println(a);
	//System.out.println(s.b);

	Satara3 s1 = new Satara3 ();
	System.out.println(s1.a);
	System.out.println(s1.b);
	
	Satara3 s2=new Satara3 ('@','%');
    System.out.println(s2.a);
    System.out.println(s2.b);
		
	int v='&';
	System.out.println(v);
	
	//System.out.println(a);
	//System.out.println(s.b);
		
	for (int n =0 ; n < 2 ; n++)
	{
	Satara3 q = new Satara3();
	q.demo(45);
	}
	

	
	for (int y =0 ; y < 2 ; y++)
	{
	Satara3 q = new Satara3();
	q.demo('#');
	}
}
}


