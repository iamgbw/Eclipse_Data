package static_nonstatic;

public class StaticAndNonStatic {
	
	static int a = 10;
		   int b = 20;	// Non-Static or Instance element
		   
		   
		   public static void main(String[] args) {
			
			   System.out.println(a);    							// static elements can call directly---> o/p = 10
			   System.out.println(StaticAndNonStatic.a);			// static element's can also call in this way---> o/p = 10	
			   
			   StaticAndNonStatic m = new StaticAndNonStatic();		// object Declaration
			   System.out.println(m.b);								// Non-Static element's can call using object---> o/p = 20
			   System.out.println(m.a);								// static element's can also call in this way---> o/p = 10
			   
			   StaticAndNonStatic n = new StaticAndNonStatic();		// object Declaration
			   System.out.println(n.b);								// Non-Static element's can call using object---> o/p = 20
			   
			   m.b = 75;											// the value 75 load in memory 'b' using object m
			   
			   System.out.println(m.b);	//It's Different Memory location ---> o/p = 75
			   System.out.println(n.b);	// It's Different Memory location---> o/p = 20
			   
			   m.a = 25;
			   System.out.println(m.a);		// o/p = 25
			   System.out.println(n.a);		// o/p = 25
			   System.out.println(StaticAndNonStatic.a); // This is Proper way to call Static elements----> o/p = 25
			   
		}

}
