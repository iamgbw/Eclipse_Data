package static_nonstatic;

public class Example2 {
	
	static int a = 45;
		   int b;
		   
		   Example2(){
			   b = 47;
		   }

		   Example2(char y){
			   b = 50;
		   }
		   
		   void demo()
		   {
			   System.out.println(b);
		   }
		   
		   public static void main(String[] args) {
			
			   Example2 d = new Example2 ();    // d.b = 47
			   d.demo();
			   
			   Example2 g = new Example2('@');	// g.b = 50 
			   g.demo();
		   }
}
