package static_nonstatic;

public class Example1 {
	
	Example1()
	{
		System.out.println("Ramanujan");
	}

	Example1 (int d)
	{
		System.out.println("Maharshi Kanad");
	}
	
	public static void main(String[] args) 
	{
	
		new Example1();
		
		System.out.println();
		
		Example1 h = new Example1 (5);
		
		new Example1 (5);
		
	}
}
