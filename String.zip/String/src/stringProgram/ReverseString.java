package stringProgram;

public class ReverseString {

public static void main(String[] args) {
		
		String a = "Velocity";   // String Declaration
				
		System.out.println(a);	// print String
		
		System.out.println("---");
		 
		String t = "";   // Dummy String
		
		for (int i = (a.length()-1); i >= 0 ; i--)
		{
			t = t + a.charAt(i);
		}
		
		System.out.print(t);
		
		System.out.println();
		
		System.out.println("---");
		
		a = t ;
		
		System.out.println(a);
	}

}
