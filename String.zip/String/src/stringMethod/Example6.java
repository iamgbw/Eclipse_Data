package stringMethod;

public class Example6 {
	
	public static void main(String[] args) {
		
		String a = "Velocity";
		
		
		System.out.println( a.length() );
		
		System.out.println( a.charAt(5) );
	}

}
