package stringMethod;

public class Example10ConcatMethod {
	
public static void main(String[] args) {
		
		String a = "Velocity";
		String b = "Class";
				
		
		System.out.println( a.concat(b) );
		
		/* Or */
		
		String s = a.concat(b);
		System.out.println(s);
		
		/* Or */
		
		System.out.println(a + b);
		
		/* Or */
		
		System.out.println(a + " " + "Class");
	}

}
