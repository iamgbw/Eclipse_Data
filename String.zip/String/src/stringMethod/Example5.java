package stringMethod;

public class Example5 {

	public static void main(String[] args) {
			
		String a = "Velocity";
		String b = "VELOciTy";
		
		String c = new String("Velocity");
		String d = new String("Velocity");
		
		System.out.println( a.toUpperCase() );
		
		System.out.println(a);
		
		String x1 = a.toUpperCase();
		System.out.println(x1);
		
		System.out.println("-------");
		
		/* If we save any result of the method in perticular 
		 element then and then only it changes respective
		 elelment (Here String) else NOT */
		
		System.out.println( b.toLowerCase() );
		
		System.out.println(b);
		
		String x2 = b.toLowerCase();
		System.out.println(x2);
	}

}
