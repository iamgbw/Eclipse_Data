/*Q. Seperate the all Alphabet's, number's, Special Symbol's from given String */

package stringMethod;

public class Example17 {
	
public static void main(String[] args) {
		
		String b = "G@ne$#!123";
		
		int a = b.length();
		
		System.out.println(b);
		
		String letter = "";
		String number = "";
		String symbol = "";
		
		for ( int i = 0 ; i < a ; i++)
		{
			char c = b.charAt(i);
			
			if(Character.isAlphabetic(c))
			{
				letter = letter + c;
			}
			else if(Character.isDigit(c))
			{
				number = number + c;
			}
			else
			{
				symbol = symbol + c;
			}
		}
		
		System.out.println(letter);
		System.out.println(number);
		System.out.println(symbol);
		
	}
}
