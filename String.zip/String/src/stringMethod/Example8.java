package stringMethod;

public class Example8 {
	
	
	public static void main(String[] args) {
		
		String a = "Velocity";
		
		for(int i = (a.length()-1) ; i > 0 ; i--)
		{
			System.out.println( a.charAt(i) );
		}
	}

}
