package stringMethod;

public class Example4MethodsOfString {
	
	public static void main(String[] args) {
		
		String a = "Velocity";
		String b = "Velocity";
		
		String c = new String("Velocity");
		String d = new String("Velocity");
		
		/* compare String a with Data Velocity */
		boolean result = a.equals("Velocity");
		System.out.println(result);
		
		/* compare String a with String c */
		result = a.equals(c);
		System.out.println(result);
		
		/* compare String a with Data Velocity */
		result = a.equals("velocity"); // small case 'v' in data
		System.out.println(result);
		
		
		/* compare String a with Data Velocity ignore case of data */
		
		result = a.equalsIgnoreCase("velocity");
		System.out.println(result);
		
		System.out.println( a.equalsIgnoreCase("velocity") );
		
	}

}
