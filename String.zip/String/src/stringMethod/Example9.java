package stringMethod;

public class Example9 {

	public static void main(String[] args) {
		
		String a = "Velocity";
		
		for(int i = (a.length()-1) ; i >= 0 ; i--)
		{
			System.out.print( a.charAt(i) );
		}
		
		System.out.println();
		System.out.println(a);
	}
}
