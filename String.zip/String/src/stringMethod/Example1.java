package stringMethod;

public class Example1 {
	
	public static void main(String[] args) {
		
		String a = "Velocity";
		String b = "Velocity";
		
		String c = new String("Velocity");
		String d = new String("Velocity");
		
		// Compare Address of String
		System.out.println( a == b ) ;
		System.out.println( c == d ) ;
		System.out.println( a == c ) ;
		System.out.println( a == d ) ;
		System.out.println( b == c ) ;
		System.out.println( b == d ) ;
		

		
	}

}
