package stringMethod;

public class Example7 {

	public static void main(String[] args) {
		
		String a = "Velocity";
		
		for(int i = 0 ; i < a.length() ; i++)
		{
			System.out.println( a.charAt(i) );
		}
	}
	
}
