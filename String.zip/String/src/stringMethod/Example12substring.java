package stringMethod;

public class Example12substring {

	public static void main(String[] args) {
		
		String a = "Velocity Testing Batch";
		
		/* substring - 1 */
		
		System.out.println( a.substring(12) );   // O/p --> from index 12 to last index
		
		/* substring - 2 */
		
		System.out.println( a.substring(5, 14) ); // O/p--> from index 5 to index 13 
	}
}
