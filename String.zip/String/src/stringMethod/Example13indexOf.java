package stringMethod;

public class Example13indexOf {

	public static void main(String[] args) {
		
		String a = "Velocity Class pune katraj Class testing Class";
		
		
		System.out.println( a.indexOf('a'));
		
		/* It gives the first index of char 'a' from given String */ 
		
		System.out.println( a.indexOf("Class") );
		
		/* It gives first index of char 'c' which has a part of a word "class" from given String */ 
		
		System.out.println( a.lastIndexOf('a') );
		
		/* It gives the last index of char 'a' from given String */ 
		
		System.out.println( a.lastIndexOf("Class") );
		
		/* It gives last index of char 'c' which has a part of a word "class" from given String */ 

	}
}
