package stringMethod;

public class Example18BhagyashriOneByOneLetterPrint {

	public static void main(String[] args) {
		
		String a = "Bhagyashri";
	
		for (int i = 0 ; i < a.length() ; i++)
		{
			System.out.println(a.charAt(i));
		}
		
		System.out.println();
		System.out.println("=============");
		System.out.println();
		
		String str = "This is last index of example";
		int index = str.lastIndexOf("example");
		System.out.println(index);//28

		for (int i = 0 ; i < str.length() ; i++)
		{
			System.out.println(str.charAt(i));
		}
	}
}


/*
 length();
 -> It is NonStatic method.
 -> Source	   => This method is from String Class.
 -> Argument   => Zero
 -> ReturnType => int
 -> Purpose    => It gives the length of respective String.
 
 */





