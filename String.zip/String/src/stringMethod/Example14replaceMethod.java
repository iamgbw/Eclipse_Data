package stringMethod;

public class Example14replaceMethod {
	
	

	public static void main(String[] args) {
		
		String a = "Velocity class batch class pune 2021 class" ;
		
		/* replace Method Type-1*/
		
		System.out.println( a.replace('a', '*') );
		
		String s =a.replace('a', '$');
		System.out.println(s);
		
		/* replace Method Type-2*/
		
		System.out.println( a.replace("class", "BATCH") );
		
		String U =a.replace("class" , "Pune");
		System.out.println(U);
	}
}
