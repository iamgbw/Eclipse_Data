package stringMethod;

public class Example2 {
	
public static void main(String[] args) {
		
		String a = "Velocity";
		String b = "velocity";
		
		String c = new String("Velocity");
		String d = new String("velocity");
		
		// Compare Address(Constant Pool Area) of String
		System.out.println( a == b ) ;
		
		// Compare Address(NonConstant Pool Area) of String
				System.out.println( c == d ) ;
		
		
	}

}
