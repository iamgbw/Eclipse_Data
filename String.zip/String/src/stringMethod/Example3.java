package stringMethod;

public class Example3 {
	
public static void main(String[] args) {
		
		String a = "Velocity";
		String b = "velocity";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println( a == b );
		System.out.println("----------");
		
		
		b = "Class" ;
		System.out.println(a);
		System.out.println(b);
		System.out.println( a == b );
		System.out.println("----------");
		
		
		b = "Velocity" ;
		System.out.println(a);
		System.out.println(b);
		System.out.println( a == b );
	}

}
