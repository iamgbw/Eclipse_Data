package stringMethod;

public class Example15SplitMethod {
	
	public static void main(String[] args) {
		
		String a = "Velocity class batch class pune 2021 class" ;

		//System.out.println( a.split(" ") );
		/* It's Return Type is Array Of String*/
		
		String d [] = a.split(" ");
		for (int i = 0 ; i < d.length ; i++)
		{
			System.out.println( d[i] );
		}
		
		System.out.println("----------");
		/* OR */
		
		String n [] = a.split("class");
		for (int i = 0 ; i < n.length ; i++)
		{
			System.out.println( n[i] );
		}
	}

}
