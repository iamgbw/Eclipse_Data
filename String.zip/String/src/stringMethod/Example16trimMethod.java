package stringMethod;

public class Example16trimMethod {
	
	public static void main(String[] args) {
		
		String a = "Velocity class batch class pune 2021 class" ;

		System.out.println(a);
		System.out.println( a.trim() );
		
		System.out.println("-------------------");
		
		String b = "     Velocity class     pune 2021     " ;
		System.out.println(b);
		System.out.println( b.trim() );

	}

}
