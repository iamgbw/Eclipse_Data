package MethodOverriding;

public class superclass {
	
	public void demo()
	{
		System.out.println("SuperClass");
	}
}
