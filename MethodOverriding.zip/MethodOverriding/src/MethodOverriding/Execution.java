package MethodOverriding;

public class Execution {
	
	public static void main(String[] args) {
		
		subclass s1 = new subclass ();
		s1.demo();
		
		superclass s2 = new superclass();
		s2.demo();
	}

}
