package MethodOverriding;

public class subclass extends superclass {

	public void demo()
	{
		System.out.println("SubClass");
	}
	//demo is inherit from superclass
	
}
