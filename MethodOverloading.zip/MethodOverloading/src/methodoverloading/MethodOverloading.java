/*Declearing a multiple method in a "same class"
 with same method name and different Argument's
 is Called as "Method Overloading". */
// Method Overloading is valid for both Static & Non-Static
// Calling of method is based on Argument

package methodoverloading;

public class MethodOverloading {
	
	public static void test()
	{
		System.out.println("test");
	}

	public static void test(int a)
	{
		System.out.println("int type test");
	}
	
	public static void test(char y)
	{
		System.out.println("char type test");
	}
	
	public static void main(String[] args) {
		
		MethodOverloading.test();
		MethodOverloading.test(12);
		MethodOverloading.test('Y');
		
	}
}
