/*Declearing a multiple method in a "same class"
 with same method name and different Argument's
 is Called as "Method Overloading". */
// Method Overloading is valid for both Static & Non-Static


package methodoverloading;

public class MethodOverloading2 {
	
	public void test()
	{
		System.out.println("test");
	}

	public void test(int a)
	{
		System.out.println("int type test");
	}
	
	public void test(char y)
	{
		System.out.println("char type test");
	}
	
	public static void main(String[] args) {
		MethodOverloading2 m = new MethodOverloading2();
		m.test();
		m.test(12);
		m.test('Y');
		
	}
}
