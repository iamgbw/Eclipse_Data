module InheritanceExample2 {
}