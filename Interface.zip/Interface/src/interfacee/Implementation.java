package interfacee;

public class Implementation implements Intr {

	
	public void main() {
		System.out.println("main");
	}


	public void test() {
	System.out.println("test");
	}

	
	public void demo() {
	System.out.println("demo");	
	}

	public void defaultTest ()			// public
	{
		System.out.println("Overrided defaultTest");
	}
}
