package interfacee;

public class Execution {

public static void main(String[] args) {
		
		//Intr i = new Intr ();
		
		Implementation i = new Implementation () ;
		i.main();
		i.test();
		i.demo();
		
		//System.out.println(a);
		System.out.println(Intr.a);
		System.out.println(Implementation.a);
		
		// static method
		Intr.staticTest();
		//Implementation.staticTest();
/* implements keyword can not inherit static property */
/* To call static method we use interfaceName */
		
		// default method
		//Intr.defaultTest();
		//Implementation.defaultTest();
		i.defaultTest();
/* To call default method we use object of implementation class */
	

	}
}
