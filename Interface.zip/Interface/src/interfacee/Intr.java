package interfacee;

public interface Intr {
	
	int a = 10 ;   // public, static & final
	
	void main () ; // public & abstract
	void test () ; // public & abstract
	void demo () ; // public & abstract
	
	static void staticTest ()			// public
	{
		System.out.println("staticTest");
	}
	
	 default void defaultTest ()			// public
	{
		System.out.println("defaultTest");
	}

	
}
