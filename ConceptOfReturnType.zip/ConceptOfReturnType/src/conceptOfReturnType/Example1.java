package conceptOfReturnType; // see recording on date 08-01-2022

public class Example1 {
	
	static int add (int a, int b)
	{
		int r = a + b;
		return r;
	}
	
	private static void sub(int a, int b)
	{
		int r2 = a - b;
		System.out.println(r2);
	}
	public static void main(String[] args) {
		
		int result;
		result = add(30,40);
		System.out.println(result);
		
		sub (10,5);
	}
}
