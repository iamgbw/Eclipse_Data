package conceptOfReturnType;

public class Example2 {
	
	static void add (int a, int b) //Arguments are input to the method
	{
		int r = a+b;
	
		System.out.println(a);
		System.out.println(b);
		System.out.println(r);
	}
	
	static int sub (int a, int b)
	{
		int r = b-a;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(r);
		return r;
	}
	
	public static void main(String[] args) {
		add(30,40);
		add(50,50);
		add(40,90);
		add(100,120);
		
		System.out.println();
		int result;
		result = sub(30,40);
		System.out.println(result);
		result = sub(50,50);
		System.out.println(result);
		result = sub(40,90);
		System.out.println(result);
		result = sub(100,120);
		System.out.println(result);

		
	}

}
