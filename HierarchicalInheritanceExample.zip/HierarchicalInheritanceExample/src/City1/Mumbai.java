package City1;

public class Mumbai extends Delhi {

	public void alpha ()
	{
		System.out.println("Alpha");
	}
}
