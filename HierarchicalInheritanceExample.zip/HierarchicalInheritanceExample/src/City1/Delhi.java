package City1;

public class Delhi {

	public void test ()
	{
		System.out.println("Test");
	}

	public void demo ()
	{
		System.out.println("Demo");	
	}
}
