package City2;

import City1.Delhi;
import City1.Mumbai;

public class Execution {
	
	public static void main(String[] args) {
		
		// Normal Concept
		Delhi d = new Delhi ();
		d.test();
		d.demo();
		
		Mumbai m = new Mumbai ();
		m.alpha();
		
		Hyderabad h = new Hyderabad ();
		h.Gamma();
		
		Bengaluru b = new Bengaluru ();
		b.Beta();
		
		System.out.println();
		System.out.println();
		
		//Hierarchical Inheritance 
		m.test();
		m.demo();
		
		System.out.println();
		
		h.test();
		h.demo();
		
		System.out.println();
		
		b.test();
		b.demo();
		
	}
}
