package City2;

import City1.Delhi;

public class Hyderabad extends Delhi {

	public void Gamma()
	{
		System.out.println("Gamma");
	}
}
