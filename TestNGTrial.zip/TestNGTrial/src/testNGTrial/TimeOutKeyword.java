package testNGTrial;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TimeOutKeyword {

	@BeforeClass
	public void beforeClass() {
		System.out.println("beforeClass");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("beforeMethod");
	}
	
	@Test 
	public void testA() {
		System.out.println("test A");
	}
	
	@Test ( timeOut = 3000 )  	// timeOut = 3000 milisec = 3 sec
	public void testB() {
		System.out.println("test B");
	}
	
	@Test 
	public void testE() {
		System.out.println("test E");
	}
	
	@AfterMethod
	public void afterMethod() {
		System.out.println("afterMethod");
	}
	
	@AfterClass
	public void afterClass() {
		System.out.println("afterClass");
	}
}
