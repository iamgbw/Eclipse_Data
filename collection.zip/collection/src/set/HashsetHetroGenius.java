package set;

import java.util.HashSet;
import java.util.Iterator;

public class HashsetHetroGenius {

	public static void main(String[] args) {
		
		HashSet h = new HashSet ();
		
		h.add(261);
		h.add("Velocity");
		h.add('h');
		h.add(12.4651);
		h.add(261);
		
		Iterator i = h.iterator();
		
		String s = h.toString();
		for ( s : h)
		{
			System.out.println( i.next() );
		}
	}
}
