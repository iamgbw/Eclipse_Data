package set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetHomoGeniusInteger {


	
	public static void main(String[] args) {
	
		HashSet<Integer> h = new HashSet<Integer>();
		
		h.add(1994);
		h.add(345);
		h.add(143);
		h.add(1994);
		h.add(786);
		h.add(134);
		h.add(143);
		h.add(786);
		
		Iterator<Integer> i = h.iterator();
		
		for (int a : h)
		{
			System.out.println( i.next() );
		}
		
		System.out.println("--------------");
		
		i = h.iterator();
		
		while (i.hasNext())
		{
			System.out.println( i.next() );
		}
	}
	
}
