package list;

import java.util.ArrayList;

public class ArrayListHomoGeniusNumeric {

public static void main(String[] args) {
		
		ArrayList<Integer> a = new ArrayList<Integer>();
		
		a.add(125);
		//a.add("Velocity");
		//a.add('s');
		//a.add(12.256);
		a.add(12);
		a.add(47);
		a.add(125);
		a.add(57);
		a.add(89);
		a.add(125);
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
		
		a.remove(2);
		
		System.out.println("---------------------------------");
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
	}
}
