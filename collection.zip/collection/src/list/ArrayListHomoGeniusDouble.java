package list;

import java.util.ArrayList;

public class ArrayListHomoGeniusDouble {

public static void main(String[] args) {
		
		ArrayList<fraction> a = new ArrayList<fraction>();
		
		//a.add(125);
		//a.add("Velocity");
		//a.add('s');
		a.add(12.256);
		a.add('@');
		a.add('#');
		a.add('%');
		a.add('&');
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
		
		a.remove(2);
		
		System.out.println("---------------------------------");
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
	}
}
