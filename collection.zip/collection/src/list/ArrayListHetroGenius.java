package list;

import java.util.ArrayList;

public class ArrayListHetroGenius {

	public static void main(String[] args) {
		
		ArrayList a = new ArrayList();
		
		a.add(125);
		a.add("Velocity");
		a.add('s');
		a.add("Velocity");
		a.add(12.256);
		a.add(125);
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
		
		a.remove(2);
		
		System.out.println("---------------------------------");
		
		for (int i = 0 ; i < a.size() ; i++ )
		{
			System.out.println( a.get(i) );
		}
		
		System.out.println("---------------------------------");
		
		
	}
}
