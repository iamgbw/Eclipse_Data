package hashtable;

import java.util.Hashtable;
import java.util.Map;

public class HashtableConcept2 {

		public static void main(String[] args) {
			   // Key, Value
		Hashtable<Integer, String> t = new Hashtable<Integer, String>();
		
		t.put(12, "Velocity");
		t.put(225, "Batch");
		t.put(125, "Class");
		t.put(47, null);
		t.put(458, "2022");
		t.put(489, "Velocity");
		t.put(145, null);
		
		for(Map.Entry<Integer, String> e : t.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
		
		t.put(null, "Nov- B");
		
		System.out.println("==============================");
		
		for(Map.Entry<Integer, String> e : t.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
	}
}
