package hashMap;

import java.util.HashMap;
import java.util.Map;

public class HashMapp {

	public static void main(String[] args) {
			   // Key, Value
		HashMap<Integer, String> h = new HashMap<Integer, String>();
		
		h.put(12, "Velocity");
		h.put(225, "Batch");
		h.put(125, "Class");
		h.put(47, "Nov-A");
		h.put(458, "2022");
		h.put(489, "Velocity");
		h.put(145, "Class");
		
		for(Map.Entry<Integer, String> e : h.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
		
		h.put(47, "Nov- B");
		
		System.out.println("==============================");
		
		for(Map.Entry<Integer, String> e : h.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
	}
}
