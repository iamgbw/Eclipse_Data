package hashMap;

import java.util.HashMap;
import java.util.Map;

public class HashMapNullKeyConcept {

		public static void main(String[] args) {
			   // Key, Value
		HashMap<Integer, String> h = new HashMap<Integer, String>();
		
		h.put(12, "Velocity");
		h.put(null, "Batch");
		h.put(125, "Class");
		h.put(47, null);
		h.put(458, "2022");
		h.put(489, "Velocity");
		h.put(145, null);
		
		for(Map.Entry<Integer, String> e : h.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
		
		h.put(null, "Nov- B");
		
		System.out.println("==============================");
		
		for(Map.Entry<Integer, String> e : h.entrySet() )
		{
			System.out.println("Key= " + e.getKey() + " => " + " Value= " + e.getValue() );
		}
	}
}
