package upCasting;

public class Execution {

	public static void main(String[] args) {
		
		//object of Superclass
		Superclass s1 = new Superclass ();
		s1.test();
		
		//Inheritance
		//Object of Subclass
		Subclass s2 = new Subclass ();
		s2.test();
		
		//Upcasting Object
		Superclass s3 =new Subclass ();
		s3.test();
	}
}
