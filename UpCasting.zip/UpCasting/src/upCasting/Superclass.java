package upCasting;

public class Superclass {

	public void test ()
	{
		System.out.println("Hi");
	}
}
