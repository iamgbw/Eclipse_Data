package upCasting;

public class Subclass extends Superclass {

	public void test ()
	{
		System.out.println("Hello");
	}
}
