//Impact of protected Access Specifier on Inheritance

package City1;

public class Delhi {
	
	protected void demo ()
	{
		System.out.println("Demo");
	}

}
