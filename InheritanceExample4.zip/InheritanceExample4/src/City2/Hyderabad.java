package City2;

import City1.Delhi;

public class Hyderabad extends Delhi {

	public static void main(String[] args) {
		
		Hyderabad h = new Hyderabad ();
		h.demo();
		// Protected properties can be inherite outside the package
		
		Delhi d = new Delhi ();
		//d.demo();
		// But Protected properties can not call outside the package
	}
}
