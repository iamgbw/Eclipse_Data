package North;

public class Delhi {
	
	public 	static int a = 10 ;
		   	static int b = 20 ;
	protected static int c = 30 ;

	private static int d = 40 ;
	
	public static void main(String[] args) {
		
		System.out.println(a);	// public
		System.out.println(b);	// Default
		System.out.println(c);	// protected
		System.out.println(d);	// private
	}
}
