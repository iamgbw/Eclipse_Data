package North;

public class Mumbai {
	
public static void main(String[] args) {
		
		System.out.println(Delhi.a);	// public
		System.out.println(Delhi.b);	// Default
		System.out.println(Delhi.c);	// protected
		//System.out.println(Delhi.d);	// private
	}

}
