package South;

public class Hyderabad2 {
	
public static void main(String[] args) {
		
		System.out.println(North.Delhi.a);	// public
		//System.out.println(North.Delhi.b);	// Default
		//System.out.println(North.Delhi.c);	// protected
		//System.out.println(North.Delhi.d);	// private
		
		/*if we don't use "import North.delhi" command (in the package and outside the class) 
		then we have mention every time class name to call the property 
		Example is given above */
		
		/* Here default is not used because it's property
		--> the scope Default is within package only */ 
		
				// &
		
		/* Here protected is not used because it's property
				--> the scope protected is within package only
				--> if we inherit the property then we can use protected property */
		
		
				//&
	
		
		/* Here private is not used because it's property
		--> the scope private is within class only */
	}

}
