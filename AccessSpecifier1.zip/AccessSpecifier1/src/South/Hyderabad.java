package South;

import North.Delhi;

public class Hyderabad {
	
	public static void main(String[] args) {
		
		System.out.println(Delhi.a);	// public
		//System.out.println(Delhi.b);	// Default
		//System.out.println(Delhi.c);	// protected
		//System.out.println(North.Delhi.d);	// private
	}

}
