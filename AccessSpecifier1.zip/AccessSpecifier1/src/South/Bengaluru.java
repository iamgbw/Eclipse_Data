package South;

import North.Delhi;

public class Bengaluru extends Delhi {
	
public static void main(String[] args) {
		
		System.out.println(Bengaluru.a);			// public
		//System.out.println(Bengaluru.b);			// Default
		System.out.println(Bengaluru.c);			// protected
		//System.out.println(North.Bengaluru.d);	// private
	
		
		/* here we inheritate the property from Delhi class
		therefore we can use protected property */
	}

}
