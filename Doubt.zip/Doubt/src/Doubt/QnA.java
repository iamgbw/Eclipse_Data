package Doubt;



public class QnA {
	


}
