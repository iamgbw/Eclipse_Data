package datatype;

public class Data_Type {
	
	//type "main" ==> ctrl + space ==> enter
	public static void main(String[] args) {
		
		boolean a = false;
		//type "syso" ==> ctrl + space ==> enter
		System.out.println(a);
		
		byte b = 14;
		//type "syso" ==> ctrl + space ==> enter
		System.out.println(b);
		
		short c = 127;
		System.out.println(c);
		
		int d = 256;
		System.out.println(d);
		
		long e = 123456789;
		System.out.println(e);
		
		float f = 0.12345678f;     // print upto maximum 8 decimal places
		System.out.println(f);
		
		double g = 0.123456789101112131415161718;
		System.out.println(g);	
		
		char h = '$';
		System.out.println(h);
		
		String i = "Chatrapati Shivaji Maharaj";
		System.out.println(i);
		
		System.out.println("Chatrapati Sambhaji Maharaj");
		
	}

}
