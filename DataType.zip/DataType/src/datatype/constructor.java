package constructor;

public class Mumbai 
{
	static int a=10;
		   int b;
	Mumbai()
	{
		a=58;
		b=49;	
	}
	
	Mumbai(int g)
	{
		a=90;
		b=63;	
	}
	
	public static void main(String[]args)
	
	{
		System.out.println(Mumbai.a);
		
		Mumbai x = new Mumbai();
		
		System.out.println(x.a);
		System.out.println(x.b);
		
	      x.a = 30;
		
		Mumbai y = new Mumbai(111);
		
		System.out.println(y.a);
		System.out.println(y.b);
		
		System.out.println(x.a);
		System.out.println(y.a);
			
	}
	
}