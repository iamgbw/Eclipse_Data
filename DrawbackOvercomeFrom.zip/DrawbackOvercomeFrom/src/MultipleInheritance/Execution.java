package MultipleInheritance;

public class Execution extends class1 implements intr1 {

	
	public void test() {
		System.out.println("test from intr1");
		
	}

	void demo() 
	{
		System.out.println("demo from Execution");
	}
	
	public static void main(String[] args) {
		
		Execution e = new Execution () ;
		e.demo();
		e.test();
	}
}
