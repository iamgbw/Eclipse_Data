package MultipleInheritance;

public interface intr1 {
	
	void test ();

}
