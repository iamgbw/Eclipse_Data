package MultipleInheritance;

public class class1 {
	
	void demo() 
	{
		System.out.println("demo from class1");
	}

}
