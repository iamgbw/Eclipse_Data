package MultipleInheritance2;

public interface intr1 {
	
	void demo1 ();

}
