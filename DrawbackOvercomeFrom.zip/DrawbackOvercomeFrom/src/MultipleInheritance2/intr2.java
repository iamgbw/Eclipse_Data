package MultipleInheritance2;

public interface intr2 {
	
	void demo2 ();

}
