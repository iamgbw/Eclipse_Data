package MultipleInheritance2;

public class implementation implements intr1, intr2{

	public void demo1() {
		System.out.println("demo1");
	}


	public void demo2() {
		System.out.println("demo2");
	}

}
