package MultipleInheritance2;

public class execution {
	
	public static void main(String[] args) {
		implementation i = new implementation ();
		i.demo1();
		i.demo2();
	}

}
