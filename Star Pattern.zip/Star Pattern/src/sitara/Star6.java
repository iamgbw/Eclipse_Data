package sitara;

public class Star6 {
	
	public static void main(String[] args) 
	{
	for (int a = 0 ; a <= 10 ; a++)
	{
		for (int b = 10 ; b >= a ; b--)
		{
			System.out.print("*");
		}
		System.out.println();
	}
	}

}
