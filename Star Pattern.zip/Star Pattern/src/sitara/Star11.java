package sitara;

public class Star11 {
	public static void main (String [] args)
	{
		for (int a = 1 ; a < 11 ; a++)
		{
			for (int b = 10 ; b >= a ; b--)
			{
				System.out.print("* ");
			}
				System.out.println();

			
			for (int c = 1 ; c <=a ; c++)
			{
				System.out.print(" ");
			}
				
		}
	}

}
