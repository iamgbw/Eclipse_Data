package sitara;

public class Star9 {

	public static void main(String[] args) {
		
		for (int a = 10 ; a > 0 ; a--)
		{
			for (int b = 1 ; b < a ; b++)
			{
				System.out.print(" ");
			} 
			

			for (int c = 11; c > a; c--)
			{
				System.out.print("* ");
			}

			System.out.println();
		}
	}
}
