package sitara;

public class Star14 {
	
	public static void main(String [] args)
	{
		
		
		for (int a = 1; a <= 10; a++)
		{
			for (int b = 9 ; b >= a ; b--)
			{
				System.out.print(" ");
			}
			for (int c = 1 ; c <= a ; c++ )
			{
				System.out.print("*");	
		}
				
		for (int d = 1; d <= 4; d++)
		{
			System.out.print(" ");
		}	
		
		
		for (int b = 1 ; b <= a  ; b++)
		{
			System.out.print("*");
		}

			System.out.println(" ");
		}
					
	
		for (int d = 1; d <= 2; d++)
		{
			System.out.println(" ");
		}	
		
		
		for (int a = 10; a >= 1; a--)
		{
			for (int b = 9 ; b >= a ; b--)
			{
				System.out.print(" ");
			}
			for (int c = 1 ; c <= a ; c++ )
			{
				System.out.print("*");	
		}
				
		for (int d = 1; d <= 4; d++)
		{
			System.out.print(" ");
		}	
		
		
		for (int b = 1 ; b <= a  ; b++)
		{
			System.out.print("*");
		}

			System.out.println(" ");
		}
					
	}

}
