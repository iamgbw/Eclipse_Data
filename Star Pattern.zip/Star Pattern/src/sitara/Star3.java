package sitara;

public class Star3 {
	public static void main(String[] args) {
		for (int a=0; a<5; a++)            // defines number of Row's
		{
			for (int b=0;b<3; b++)   // Define number of Star's
			{
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("END");
	}

}