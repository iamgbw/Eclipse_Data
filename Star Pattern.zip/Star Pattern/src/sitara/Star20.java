package sitara;

public class Star20 {
	//static int a,c;
	public static void main(String[] args) {
		
		
		for (int i = 1 ; i <= 8 ; i++)
		{
			for(int j = 7 ; j >= 0 ; j--)
			{
				System.out.print(" ");
			}
			
			for(int k = 1 ; k <= 8 ; k++)
			{
				if(i >= 2 && k >= 2 && i <= 9 && k <= 9 )
				{
					System.out.print("  ");
				}
			0	else
				{
					System.out.print("* ");
				}
				System.out.println();
			}
		}
	}
}
