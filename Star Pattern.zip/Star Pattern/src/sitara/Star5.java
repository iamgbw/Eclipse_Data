package sitara;

public class Star5 {
	public static void main(String[] args) {
		
		for (int b= 0; b <= 10; b++)
		{
			for (int a = 0; a <= b; a++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
	}

}
