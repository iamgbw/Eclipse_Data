package sitara;

public class Star4 {
	public static void main(String[] args) {
		for (int a=1; a<=10; a++)
		{
			for (int b=0; b<a; b++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("END");
	}

}
