package sitara;

public class StarD {

	public static void horizontalLine()
	{
		for(int a = 0 ; a <= 15 ; a++)
		{
			System.out.print("*");
		}
		System.out.println();
	}
	
	public static void threeStar()
	{
		for(int a = 0 ; a < 3 ; a++)
		{
			System.out.print("*");
		}
	}
	
	public static void main(String[] args) {
		
		for(int i = 0 ; i < 3 ; i++)
		{
			StarD.horizontalLine();
		}
		
		for (int i = 0 ; i <= 10 ; i++)
		{
			StarD.threeStar();
			
			for (int j = 0 ; j < 10 ; j++)
			{
				System.out.print(" ");
			}
			
			StarD.threeStar();
			
			System.out.println();
		}
		
		for(int i = 0 ; i < 3 ; i++)
		{
			StarD.horizontalLine();
		}
		
		
	}
}
