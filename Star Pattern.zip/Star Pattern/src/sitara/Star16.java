package sitara;

public class Star16 {
public static void main(String[] args) throws InterruptedException {
		
		for (int a = 10; a >= 1; a--)
		{
			for (int b = 9 ; b >= a ; b--)
			{
				System.out.print("_");
				Thread.sleep(500);
			}
			for (int c = 1 ; c <= a ; c++ )
			{
				System.out.print("*");
				Thread.sleep(500);
		}
				
		/*for (int d = 1; d <= 1; d++)
		{
			System.out.print(" ");
		}*/	
		
		
		for (int b = 1 ; b <= (a - 1)  ; b++)
		{
			System.out.print("*");
			Thread.sleep(500);
		}

			System.out.println("_");
			Thread.sleep(500);
		}
	}

}
