package sitara;

public class StarC {

	public static void horizontalLine()
	{
		for(int a = 0 ; a <= 15 ; a++)
		{
			System.out.print("*");
		}
		System.out.println();
	}
	
	public static void threeStar()
	{
		for(int a = 0 ; a < 3 ; a++)
		{
			System.out.print("*");
		}
	}
	public static void main(String[] args) {
		
		for(int i = 0 ; i < 3 ; i++)
		{
			StarC.horizontalLine();
		}
		
		for (int j = 0 ; j < 10 ; j++)
		{
			StarC.threeStar();
			
			for(int i = 0 ; i <= 15 ; i++)
			{
				System.out.print(" ");
			}
			System.out.println();
		}
		
		for(int i = 0 ; i < 3 ; i++)
		{
		StarC.horizontalLine();
		}
	}
}
