package sitara;

public class Star2 {
	public static void main(String[] args) {
		for (int a = 0 ; a < 5 ; a++)
		{
			System.out.print("*");
		}
		System.out.println(" ");
		System.out.println("End");
	}

}
