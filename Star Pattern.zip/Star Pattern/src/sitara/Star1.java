package sitara;

public class Star1 {
	public static void main(String[] args) {
		for (int a=0 ; a < 4 ; a++)
		{
			System.out.println("*");
		}
		System.out.println("END");
	}

}
