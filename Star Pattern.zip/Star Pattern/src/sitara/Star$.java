package sitara;

public class Star$ {

}
