package sitara;

public class Star13 {
	
	public static void main(String[] args) {
		
		for (int b = 8 ; b >= 1 ; b--)
		{
			for (int a = 1 ; a <= b ; a++)
			{
				System.out.print("*");
			}
			
			System.out.println(" ");	
		}

		for (int b = 1 ; b <= 8 ; b++)
		{
			for (int a = 0 ; a <= b ; a++)
			{
				System.out.print("*");
			}
			
			System.out.println(" ");	
		}
	}
	
}
