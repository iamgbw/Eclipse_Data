package sitara;

public class Star18 {
	
	static void SachinV()
	{
		for (int s = 0 ; s <=  6 ; s++)
		{
			System.out.print("*");
		}
		System.out.println();
	}

	public static void main(String[] args) 
	{	
		Star18.SachinV();
		int f = 6;
		for(int g = 0 ; g < f; g++)
		{			
			if ((g != 0) && (g != 6))
			{
				System.out.print("*");
				for(int y = 0 ; y < 5 ; y++)
				{
					System.out.print(" ");
				}
				System.out.println("*");		
			}
		}
		Star18.SachinV();
	}
}
