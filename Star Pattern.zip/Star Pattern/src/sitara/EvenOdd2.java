package sitara;

public class EvenOdd2 {
	public static void main(String[] args) {
	float a=9;
	float b=a/2;
	System.out.println(b);
	if (a%2==1)  //here we find Reminder (% => Modulus/ Percentage Operator)
	{
		System.out.println("a is Odd Number");
	}
	else
	{
		System.out.println("a is Even Number");
		
	}
	System.out.println("END");

}
}