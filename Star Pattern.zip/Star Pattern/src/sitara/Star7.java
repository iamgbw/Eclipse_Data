package sitara;

public class Star7 {
	
	public static void main(String[] args) 
	{
	
	for (int a = 1 ; a <= 10 ; a++)
	{
		for (int b = 1 ; b <= a ; b++)
		{
			System.out.print("*");
		}
		System.out.println();
	}
	for (int a = 9 ; a > 0 ; a--)
	{
		for (int b = 1 ; b <= a ; b++)
		{
			System.out.print("*");
		}
		System.out.println();
	}
	
	System.out.println("END");
	}
	
	}	

