package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicationHeaderpage {
	
	@FindBy (xpath = "//div[@id='nav-logo']" )
	private WebElement amezonLogo;
	
	@FindBy (xpath = "//div[@id='nav-global-location-slot']" )
	private WebElement address;
	
	@FindBy (xpath = "//input[@aria-label='or enter an Indian pincode']" )
	private WebElement enterAnIndianPincode;
	
	@FindBy (xpath = "(//input[@type='submit'])[4]" )
	private WebElement searchDropdownBox;
	
	@FindBy (xpath = "//select[@id='searchDropdownBox']" )
	private WebElement selectSearchDropdownBox;
	
	@FindBy (xpath = "//input[@id='twotabsearchtextbox']" )
	private WebElement searchTextBox;
	
	@FindBy (xpath = "//input[@id='nav-search-submit-button']" )
	private WebElement searchSubmitButton;
	
	@FindBy (xpath = "//a[@id='icp-nav-flyout']" )
	private WebElement language;
	
	@FindBy (xpath = "//a[@id='nav-link-accountList']" )
	private WebElement accountAndList;
	
	@FindBy (xpath = "(//a[@data-nav-role='signin'])[2]" )
	private WebElement logIn;
	
	@FindBy (xpath = "//span[text()='Your Account']" )
	private WebElement yourAccount;
	
	@FindBy (xpath = "//a[@id='nav-cart']" )
	private WebElement cart;
	
	public ApplicationHeaderpage (WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnAmezonLogo()
	{
		amezonLogo.click();
	}

	public void clickOnAddress()
	{
		address.click();
	}
	
	public void clickOnEnterAnIndianPincode()
	{
		enterAnIndianPincode.sendKeys("413402");
	}
	
	public void clickOnSearchDropdownBox()
	{
		searchDropdownBox.click();
	}
	
	public void SelectSearchDropdownBox()
	{
		selectSearchDropdownBox.click();
	}
	
	public void EnterDataOnSearchTextBox()
	{
		searchTextBox.sendKeys("Books");
	}
	
	public void clickOnSearchSubmitButton()
	{
		searchSubmitButton.click();
	}
	
	public void clickOnLanguage()
	{
		language.click();
	}
	
	public void clickOnAccountAndList()
	{
		accountAndList.click();
	}
	
	public void clickOnLogIn()
	{
		logIn.click();
	}
	
	public void clickOnYourAccount()
	{
		yourAccount.click();
	}
	
	public void clickOnCart()
	{
		cart.click();
	}
	
}
