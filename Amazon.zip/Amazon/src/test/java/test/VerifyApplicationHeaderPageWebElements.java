package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class VerifyApplicationHeaderPageWebElements {
	
	private WebDriver  driver;
	
	
	@BeforeClass
	public void launchBrowser() {
		System.out.println("Launch Browser");
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	// Implicit Wait
	}
	
	

}
