//Impact of private Access Specifier on Inheritance

package AccessSpecifierWithInhertance;

public class Delhi {
	
	public static void demo ()
	{
		System.out.println("Demo");
	}

	public void alpha ()
	{
		System.out.println("Alpha");
	}
	
	private void test ()
	{
		System.out.println("Test");
	}
	
	void gamma ()	// Default Access Specifier
	{
		System.out.println("Gamma");
	}
	
	public static void main(String[] args) {
		
		Mumbai.demo ();
		
		Mumbai m = new Mumbai ();
		m.alpha();
		//m.test(); --> private element can not be Inherited
	
		Delhi d = new Delhi ();
		d.test();
	}
}
