package AccessSpecifierWithInhertance;

public class Mumbai extends Delhi {

}
