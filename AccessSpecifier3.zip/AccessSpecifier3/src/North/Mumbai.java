package North;

public class Mumbai extends Delhi{

	public static void main(String[] args) {
		
		Mumbai.Method1();		// public
		Mumbai.Method2();		// Default
		Mumbai.Method3();		// protected
		//Mumbai.Method4();		// private		
	}
}
