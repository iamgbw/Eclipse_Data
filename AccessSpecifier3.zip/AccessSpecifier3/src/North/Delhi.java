package North;

public class Delhi {
	
	public static void Method1()
	{
		System.out.println("THis is Public Method1");
	}
	
	static void Method2()
	{
		System.out.println("THis is Default Method2");
	}
	
	protected static void Method3()
	{
		System.out.println("THis is protected Method3");
	}

	private static void Method4()
	{
		System.out.println("THis is private Method4");
	}
	
	public static void main(String[] args) {
		
		Method1();		// public
		Method2();		// Default
		Method3();		// protected
		Method4();		// private
		
	}
}
