package South;

import North.Delhi;

public class Bengaluru extends Delhi {
	
public static void main(String[] args) {
		
		Hyderabad.Method1();		// public
		//Hyderabad.Method2();		// Default
		Bengaluru.Method3();		// protected
		//Hyderabad.Method4();		// private
		
	}

}
