package South;

import North.Delhi;

public class Hyderabad extends Delhi {

	
	public static void main(String[] args) {
		
		Hyderabad.Method1();		// public
		//Hyderabad.Method2();		// Default
		Hyderabad.Method3();		// protected
		//Hyderabad.Method4();		// private
		
	}
}
