package MethodHiding;
public class Execution {
public static void main(String[] args) {
	subclass.demo();
	superclass.demo();
	}
}
