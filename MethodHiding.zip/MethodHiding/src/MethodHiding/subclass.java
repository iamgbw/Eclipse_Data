package MethodHiding;

public class subclass extends superclass {
	public static void demo()
	{
		System.out.println(" Overrided SubClass");
	}
	//superclass demo method is hidden   
	

}
