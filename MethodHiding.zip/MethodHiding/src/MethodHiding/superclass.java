package MethodHiding;

public class superclass {
	public static void demo()
	{
		System.out.println("SuperClass");
	}
}
