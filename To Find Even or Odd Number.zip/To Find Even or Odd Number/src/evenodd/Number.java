package evenodd;

public class Number {
	public static void main(String[] args) {
		int a=44;
		float b=a/2; //b=4.5
		int d= a%2;
		float c=b*2; //c=9
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		if (a%2==0)
		{
			System.out.println("a is Even Number");
		}
		else
		{
			System.out.println("a is Odd Number");
			
		}
		System.out.println("END");
		
	}

}
