package method;

public class NonStatic {
	
	public void nonstatic ()
	{
		System.out.println("I am Non-Static Method");
	}
	
	public static void main(String[] args) 
	{
		NonStatic n = new NonStatic();
		n.nonstatic();
		
	}

}
