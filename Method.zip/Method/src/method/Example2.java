package method;									// Declearation of package

public class Example2 {							// Declearation of class
	
	public static void Trust()					// Declearation of Static Method
	{
		
		System.out.println("a");
		System.out.println("b");
		System.out.println("c");		
	}

	public static void main(String[] args) {	//calling Main method
		System.out.println("START");
		Trust();                      			//calling static method
		System.out.println("---> d");
		Trust();								//calling static method
		System.out.println("---> e");
		Trust();								//calling static method
		System.out.println("---> f");
		System.out.println("END");
		

	
	}

}
