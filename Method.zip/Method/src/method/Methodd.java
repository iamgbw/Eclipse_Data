
package method;

public class Methodd {
	
	
	public static void StaticMethod ()
	{
		System.out.println("I am Static Method");
	}
	
	
	public void NonStaticMethod() 
	{
		System.out.println("I am Non-Static Method");
	}

	
	public static void main(String[] args) 
	{
		StaticMethod();     				// Calling Static Method
		Methodd m = new Methodd();
		m.NonStaticMethod();       			 // Calling Non-Static Method
	}
	
}
