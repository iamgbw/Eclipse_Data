package method;

public class Example1 {
	
	public static void demo () {
		System.out.println("Jay");
		System.out.println("	Jay");
	}
	
	public void test () {
		System.out.println("		Ram");
		System.out.println("			Krishna");
		System.out.println("				Hari");
	}
	
	public static void main(String[] args) {
		
		demo();
		Example1 j = new Example1 ();
		j.test();
	}

}

