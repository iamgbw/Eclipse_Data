package method;

public class StaticMethod {
	
	public static void Static ()
	{
		System.out.println("I am Static Method");
	}
	
	public static void main(String[] args) 
	{
		StaticMethod.Static();
	}

}
