package City2;

import City1.Delhi;

public class Pune extends Delhi {
	
	
	

}
