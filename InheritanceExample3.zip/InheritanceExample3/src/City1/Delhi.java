//Impact of Default and protected Access Specifier on Inheritance


package City1;

public class Delhi {
	
	public static void test ()
	{
		System.out.println("Test");
	}
	
	void demo ()
	{
		System.out.println("Demo");
	}
	
	public void alpha ()
	{
		System.out.println("Alpha");
	}
	
	protected void gamma () {
		System.out.println("Gamma");
	}
	

}
