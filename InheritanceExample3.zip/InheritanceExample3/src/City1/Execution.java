package City1;

import City2.Pune;

public class Execution {
	
	public static void main(String[] args) {
		
		Delhi d = new Delhi ();
		d.demo();
		d.gamma(); 
		
		
		
		Pune p = new Pune ();
		p.alpha(); 		//Non-Static Method
		// p.demo();
		// Default can not be Inherited out of the Package
		
		
		Pune.test();	//Static Method
		
	
		p.gamma();
		// protected properties can not be call outside the package
		// But protected properties can Inherited
	}

}
