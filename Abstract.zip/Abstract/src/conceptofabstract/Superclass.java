package conceptofabstract;

public abstract class Superclass {
	
	public static void demo ()
	{
		System.out.println("Static method");
	}
	
	public void test ()
	{
		System.out.println("non static");
	}
	
	public abstract void alpha ();

}
