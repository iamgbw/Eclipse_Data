package conceptofabstract;

public class Execution {
	public static void main(String[] args)
	{
		
//		Superclass s1 = new Superclass();
//		s1.alpha();
//		s1.test();
//		s1.alpha();
		
		Subclass s2 = new Subclass () ;
				s2.alpha();
				s2.test();
				
				Subclass.demo();
				Superclass.demo();
	}

}
