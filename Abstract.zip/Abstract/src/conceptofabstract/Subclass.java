package conceptofabstract;

public class Subclass extends Superclass {

	public void alpha() {
		System.out.println("abstract method");
	}

}
