package City1;

public class Delhi {
	
	public static int a = 12 ;
	public int b = 75 ;
	
	public static void test () 
	{
		System.out.println("test is static Method");
	}

	public void demo ()
	{
		System.out.println("demo is nonstatic");
	}
}
