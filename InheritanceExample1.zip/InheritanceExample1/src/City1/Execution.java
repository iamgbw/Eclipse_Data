package City1;

public class Execution {
	
	public static void main(String[] args) {
		
		
		
		Delhi.test();
		System.out.println(Delhi.a);
		
		Delhi d = new Delhi ();
		d.demo();
		System.out.println(d.b);
		
		System.out.println();
		System.out.println();
		
		// Multilevel Inheritance    
		// Inheritance Call
		Mumbai.test();
		System.out.println(Mumbai.a);
		
		Mumbai s = new Mumbai();
		s.demo();
		System.out.println(s.b);
		
		
		System.out.println();
		System.out.println();
		
		//Normal Concept
		s.alpha();
	}

}
