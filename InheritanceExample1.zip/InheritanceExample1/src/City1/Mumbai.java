package City1;

public class Mumbai extends Delhi {

	public void alpha ()
	{
		System.out.println("alpha is nonstatic method");
	}
}

// In this class we inherit  the following properties
// static variable "a"
//static method  "test"
//Non-Static variable "b"
//Non-Static method "demo"