package City2;

import City1.Mumbai;  // It is only used to Define Address of Mumbai Class not else

public class Hyderabad extends Mumbai {

	
		
}
