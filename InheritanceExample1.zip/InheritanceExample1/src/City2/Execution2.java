package City2;

public class Execution2 {
	
	public static void main(String[] args) {
		
		// Multilevel Inheritance
		
		Hyderabad h = new Hyderabad();
		h.alpha();
		h.demo();
		
		Hyderabad.test();
	}

}
