package entry;

public class Addition {
	public static void main(String[] args) {
		int a=5;
		int b=5;
		int c=5;
		int d=a+b+c;
		System.out.println(d);
		
	}

}
