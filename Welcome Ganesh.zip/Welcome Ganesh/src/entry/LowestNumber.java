package entry;

public class LowestNumber {
	public static void main(String[] args) {
		int a=500;
		int b=100;
		int c=40;
		int d=2;
		
		if (a<b)
		{
			if (a<c)
			{
				if (a<d)
				{
					System.out.println("a is Smollest Number");
				}
				else
				{
					System.out.println("d is Smollest Number");
				}
			}
		}
		else
		{
			if (b<c)
			{
				if (b<d)
				{
					System.out.println("b is Smollest Number");
				}
				else
				{
					System.out.println("d is Smollest Number");
				}
			}
			else
			{
				if (c<d)
				{
					System.out.println("c is Smollest Number");
				}
				else
				{
					System.out.println("d is Smollest Number");
				}
			}
			
		}
		System.out.println("END");
	}

}
