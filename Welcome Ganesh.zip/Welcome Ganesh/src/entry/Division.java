package entry;

public class Division {
	public static void main(String[] args) {
		int a=16;
		int b=2;
		int c=a/b;
		System.out.println(c);
	}

}
