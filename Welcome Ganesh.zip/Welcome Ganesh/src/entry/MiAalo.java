package entry;

public class MiAalo
{ 
		public static void main(String[] args)
{
	System.out.println("Ram Ram Gani Bhau");
	}

}
