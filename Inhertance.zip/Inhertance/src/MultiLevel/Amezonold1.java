package MultiLevel;

public class Amezonold1 {
	
	public void profile ()
	{
		System.out.println("Set Your Profile");
	}
	
	public void location ()
	{
		System.out.println("Select Delievery Location");
	}

}
