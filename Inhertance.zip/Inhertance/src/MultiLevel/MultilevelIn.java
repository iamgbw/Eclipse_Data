package MultiLevel;

public class MultilevelIn {

	public static void main(String[] args) {
		
		NewVersion n = new NewVersion () ;
		
		n.prime();
		n.Amezonacademy();
		n.Alexa();
		n.coupons();
		n.payment();
		n.scancode();
		n.reward();
		n.profile();
		n.location();
		
	}
}
