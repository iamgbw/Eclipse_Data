package MultiLevel;

public class NewVersion extends Amezonold2 {

	public void prime ()
	{
		System.out.println("Amezon's Prime");
	}
	
	public void Amezonacademy ()
	{
		System.out.println("Amezon's Academy");
	}
	
	public void Alexa ()
	{
		System.out.println("Alexa is ON");
	}
	
	public void coupons ()
	{
		System.out.println("Amezon's Coupon");
	}
}
