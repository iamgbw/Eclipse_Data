package MultiLevel;

public class Amezonold2 extends Amezonold1 {

	public void payment ()
	{
		System.out.println("Make Payment");
	}
	
	public void scancode()
	{
		System.out.println("Scan our Code here");
	}
	
	public void reward()
	{
		System.out.println("Amezon's reward");
	}
}
