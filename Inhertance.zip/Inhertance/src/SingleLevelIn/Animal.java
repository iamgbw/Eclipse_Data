package SingleLevelIn;

public class Animal {
	
	public void eat () 
	{
		System.out.println("Eating");
	}
	
	public void sleep ()
	{
		System.out.println("Sleeping");
	}

}
