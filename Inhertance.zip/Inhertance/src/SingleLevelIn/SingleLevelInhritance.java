package SingleLevelIn;

public class SingleLevelInhritance {
	
	public static void main(String[] args) {
		
		Dog d = new Dog () ;
		
		d.eat();
		d.sleep();
		d.bark();
		d.color();
		
	}

}
