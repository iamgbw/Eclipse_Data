package HierarchicalIn;

public class HumanBeing extends Animal {

	public void women ()
	{
		System.out.println("Women is Beautiful");
	}
	
	public void men ()
	{
		System.out.println("Men is Handsome");
	}
}
