package HierarchicalIn;

public class Rabbit extends Animal {

	public void color ()
	{
		System.out.println("White");
	}
	
	public void bark ()
	{
		System.out.println("Quite Creature");
	}
}
