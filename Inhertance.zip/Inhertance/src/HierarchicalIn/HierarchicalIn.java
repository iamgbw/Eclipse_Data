package HierarchicalIn;

public class HierarchicalIn {
	
	public static void main(String[] args) {
		
		Dog d = new Dog ();
		d.color();
		d.eat();
		d.sleep();
		d.drink();
		d.bark();
		System.out.println();
		System.out.println();
		
		Rabbit r = new Rabbit ();
		r.color();
		r.bark();
		r.eat();
		r.sleep();
		r.drink();
		System.out.println();
		System.out.println();
		
		HumanBeing h = new HumanBeing ();
		h.women();
		h.men();
		h.eat();
		h.drink();
		h.sleep();
		
	}

}
