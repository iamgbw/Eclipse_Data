package variable;

public class Example1 {
	
	static int a = 75;					//Global + Class Variable
		   int b = 45;				    //Global + Instance Variable
		   
		   Example1 (int q) 			//d is also Local Variable
		   {
			 int f = 100 ;  				// Local Variable 
			 System.out.println(f);
		   }
		   
		   static void test()		    // Static Method
		   {
			   int c = 56 ; 			// Local Variable
			   System.out.println(c);
			   System.out.println("This is static Method");
		   }

		   void demo()  				//Non-Static Method 
		   {
			   System.out.println("This is Non-Static Method");
		   }
		   
		   public static void main(String[] args) {
			
			   System.out.println(a);	
			   System.out.println(Example1.a);
			   
			   test();
			   Example1.test();
			   
			   Example1 z = new Example1(48);
			   z.demo();
			   
			   Example1 n = new Example1(49); // n is object created
			   System.out.println(n.a);
			   System.out.println(n.b);
			   
			   
			   
			  Example1 g = new Example1(78);
		}
}
