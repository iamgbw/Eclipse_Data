package variable;

public class LocalVariable {
	
	public static void Local1()
	{
		int a = 50 ;
		System.out.println(a);
		System.out.println();
		System.out.println("Local1 is Static Metod");
		System.out.println();
	}
	
	public void Local2()
	{
		int b = 45 ;
		System.out.println(b);
		System.out.println();
		System.out.println("Local21 is Non-Static Metod");
		System.out.println();
	}
	
	public static void main(String[] args) 
	{
		
		Local1();
		
		LocalVariable n = new LocalVariable();
		n.Local2();
		
	}

}
