package variable;

public class InstanceVariable {
	
	int a = 20 ; 
	int b = 4 ;
	
	public void Substraction()
	{
		int c = a - b ;
		System.out.println(c);
	}
	
	public void Division()
	{
		int d = a/b;
		System.out.println(d);
	}

	public static void main(String[] args) {
		
		InstanceVariable r = new InstanceVariable();
		r.Substraction();
		r.Division();
	}
}
