package variable;

public class ClassVariable {

	static int m = 100 ;
	static int n = 10 ;
	
	public void Addition()
	{
		int o = m + n ;
		System.out.println(o);
	}
	
	public static void Division()
	{
		int p = m/n ;
		System.out.println(p);
	}
	
	public static void main(String[] args) 
	{	
		ClassVariable v = new ClassVariable();
		v.Addition();
		
		Division();
		
		int A = m+n;
		System.out.println(A);
	}
	
	
	
}
