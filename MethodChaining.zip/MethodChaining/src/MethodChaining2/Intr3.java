package MethodChaining2;

public interface Intr3 {
	
	Intr2 Alpha();

}
