package MethodChaining2;

public class Execution {

	public static void main(String[] args) {
		
		Delhi d = new Delhi();
		
		Intr2 a = d.Alpha();
		
		Intr1 b = a.Beta();
		
		b.Gamma();
		
		System.out.println("---------------");
		
		
		d.Alpha().Beta().Gamma();
	}
}

// d ---> object of Delhi Class
// d.Alpha(); ---> a ---> object of Mumbai Class
// a.Beta(); ---> b ---> object of Pune Class


/* In Method Chaining 99% ReturnType is Interface */