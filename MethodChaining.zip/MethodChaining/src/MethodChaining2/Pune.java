package MethodChaining2;

public class Pune implements Intr1 {

	public void Gamma() 
	{
	System.out.println("Method Chaining");
	}

}
