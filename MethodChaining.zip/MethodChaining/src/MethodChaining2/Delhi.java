package MethodChaining2;

public class Delhi implements Intr3 {


	public Intr2 Alpha() {
		Intr2 m = new Mumbai();
		return m;
	}

}
