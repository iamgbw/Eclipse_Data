package MethodChaining2;

public class Mumbai implements Intr2
{


	public Intr1 Beta() {
		Intr1 p = new Pune();
		return p;
	}


	
}