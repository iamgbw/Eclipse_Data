package MethodChaining2;

public interface Intr1 {
	
	void Gamma();

}
