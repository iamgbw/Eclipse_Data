package MethodChaining2;

public interface Intr2 {
	
	Intr1 Beta();
}
