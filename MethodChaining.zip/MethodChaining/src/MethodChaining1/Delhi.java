package MethodChaining1;

public class Delhi 
{
	public Mumbai alpha()
	{
		Mumbai m = new Mumbai();
		return m;
	}
}
// new Mumbai(); -----> Create object of Mumbai Class---->m
// alpha() Method has ReturnType is Mumbai(i.e. Mumbai Class)
// Here Mumbai plays role of Non-Premetive DataType ---> Class
// And it's variable is m