package MethodChaining1;

public class Mumbai 
{	
	public Pune demo() {
		Pune p = new Pune();
		return p;
	}	
}
// new Pune(); -----> Create object of Pune Class---->p
// Demo Method has ReturnType is Pune(i.e. Pune Class)
// Here Pune plays role of Non-Premetive DataType ---> Class
// And it's variable is p