package MethodChaining1;

public class Pune {
	
	public void test ()
	{
		System.out.println("Test Method");
	}
}
