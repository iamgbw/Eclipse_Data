package MethodChaining1;

public class Execution {

	public static void main(String[] args) {
		
		Delhi d = new Delhi();
// Here We Create Object of Delhi Class-->d
		
		Mumbai a = d.alpha();
// By using Delhi Class object 'd' we call alpha(); method of Delhi Class
// alpha Method Provide object of Mumbai Class---->a
// And also it's ReturnType is Mumbai --->Mumbai Class
		
		Pune b   = a.demo();
// By using Mumbai Class object 'a' we call demo(); method of Mumbai Class
// demo(); method provide object of Pune class ----> b
// And also it's ReturnType is Pune
		
		b.test();
// By using Pune Class object 'b' we call test(); method of Pune Class
// test(); method does not provide any object 
// And also it's ReturnType is void
		
		System.out.println("---------------");
		
		/* Method Chaining */
		
		d.alpha().demo().test();
	}
}

/* calling of Pune Class is two time's,
 therefore Pune Class has two Different Object ---> p & b*/

		//Similarly

/* calling of Mumbai Class is two time's,
therefore Mumbai Class has two Different Object ---> m & a*/