package seleniumBasic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Trail {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.selenium.dev/downloads/");
		
	}

}


/* 
1) webdriver.chrome.driver => Is the key of Web Browser (Chrome)
2) webdriver.gecko.driver  => Is the key of Web Browser (Firefox)
3) webdriver.ie.driver		=> Is the key of Web Browser (Internet Explorer)
4) webdriver.opera.driver  => Is the key of Web Browser (Opera)
5) webdriver.edge.driver   => Is the key of Web Browser (Edge)
6) webdriver.safari.driver => Is the key of Web Browser (Safari)
*/