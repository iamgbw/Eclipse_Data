package seleniumBasic;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SetPositionMethod {
	
public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
						
		driver.navigate().to("https://www.selenium.dev/downloads/");
		Thread.sleep(3000);
		
		Dimension d = new Dimension(300, 100);	//(Length/width , Height)	
		driver.manage().window().setSize(d);
			
		Point p = new Point(900, 100); // (x,y) Co-ordinate of corner point of top-left
		driver.manage().window().setPosition(p);
	}
}



/* Code To Take Screenshot in selenium by using EventFiringWebDriver */

//		EventFiringWebDriver eDriver=new EventFiringWebDriver(driver);
//
//		File srcFile = eDriver.getScreenshotAs(OutputType.FILE);
//
//		FileUtils.copyFile(srcFile, new File(imgPath));