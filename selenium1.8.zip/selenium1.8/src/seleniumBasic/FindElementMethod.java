package seleniumBasic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindElementMethod {

	public static void main(String[] args) throws InterruptedException 
	{
			
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("https://www.facebook.com/login/");
		  	Thread.sleep(3000);
	
			By b = By.xpath("//input[@type='password']");
			Thread.sleep(3000);
			driver.findElement(b).click();
	}
}
