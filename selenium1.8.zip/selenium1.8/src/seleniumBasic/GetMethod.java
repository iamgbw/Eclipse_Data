package seleniumBasic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethod {
public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		new ChromeDriver();
		
		WebDriver fb = new ChromeDriver();
		
		driver.get("https://www.isro.gov.in/careers");
		
		fb.get("https://www.facebook.com/");
		
		driver.get("https://web.whatsapp.com/");
	}

}
