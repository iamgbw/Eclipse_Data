package seleniumBasic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MaximizeBrowser {
	
public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
						
		driver.navigate().to("https://www.selenium.dev/downloads/");
		Thread.sleep(3000);
		
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.manage().window().maximize();
	}
}


/*
                      // Metthod Chaining//
		
				driver.manage().window().maximize();
				
1) driver is object of ChromeDriver Class

2) manage();
--> It is a Non-Static Method
--> ReturnType ==> Options Interface
--> Source 	   ==> WebDriver Interface
--> It is an Abstract Method in WebDriver Interface
--> Argument   ==> Zero

3) window();
--> It is a Non-Static Method
--> ReturnType ==> Window Interface
--> Source 	   ==> Options Interface
--> It is an Abstract Method in Options Interface
--> Argument   ==> Zero

4) maximize();
--> It is a Non-Static Method
--> ReturnType ==> void
--> Source 	   ==> Window Interface
--> It is an Abstract Method in Window Interface
--> Argument   ==> Zero



*/