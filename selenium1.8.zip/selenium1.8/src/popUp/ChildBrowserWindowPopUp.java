package popUp;

import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChildBrowserWindowPopUp {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		driver.get("https://www.w3schools.com/js/js_popup.asp");
		Thread.sleep(2000);

		WebElement alert 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));
		WebElement confirm 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[2]"));
		WebElement prompt		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[3]"));
		WebElement lineBreaks   = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[4]"));
		
		alert.click();
		confirm.click();
		prompt.click();
		lineBreaks.click();
		
		String mainPage = driver.getWindowHandle();
		System.out.println("Address of mainPage => " + mainPage);
		System.out.println("URL of mainPage => " + driver.getCurrentUrl());
		System.out.println("-----------------------------------------");
		
		ArrayList<String> addr = new ArrayList<String>(driver.getWindowHandles());
		
		for (int i = 0 ; i < 5 ; i++)
		{
			System.out.println( addr.get(i) );
		}
		
		System.out.println("-----------------------------------------");
		

		driver.switchTo().window( addr.get(0) );
		System.out.println("Address of Index 0 => " + addr.get(0));
		System.out.println("URL of Index 0 => " + driver.getCurrentUrl());
		
		System.out.println("-----------------------------------------");

		driver.switchTo().window( addr.get(1) );
		System.out.println("Address of Index 1 => " + addr.get(1));
		System.out.println("URL of Index 1 => " + driver.getCurrentUrl());
		
		System.out.println("-----------------------------------------");

		driver.switchTo().window( addr.get(2) );
		System.out.println("Address of Index 2 => " + addr.get(2));
		System.out.println("URL of Index 2 => " + driver.getCurrentUrl());
		
		System.out.println("-----------------------------------------");

		driver.switchTo().window( addr.get(3) );
		System.out.println("Address of Index 3 => " + addr.get(3));
		System.out.println("URL of Index 3 => " + driver.getCurrentUrl());
		
		System.out.println("-----------------------------------------");

		driver.switchTo().window( addr.get(4) );
		System.out.println("Address of Index 4 => " + addr.get(4));
		System.out.println("URL of Index 4 => " + driver.getCurrentUrl());
		
		
		System.out.println("-----------------------------------------");

		System.out.println( "END" );

	}

}
