package popUp;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HowToHandleChildBrowserWindow {

public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		driver.get("https://www.w3schools.com/js/js_popup.asp");
		Thread.sleep(2000);
		
		System.out.println("Address of Main Page => " + driver.getWindowHandle());
		System.out.println("Url of MainPage => " + driver.getCurrentUrl());
		System.out.println("-------------------------------");
		
		WebElement alert = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));
		alert.click();
		
		ArrayList<String> addr = new ArrayList<String>( driver.getWindowHandles() );
		driver.switchTo().window( addr.get(1) ); // Here Selenium Attention jump on Child Browser Window
		
		System.out.println( "Address of Child Browser Window " + addr.get(1) );
		System.out.println("Url of Child Browser Window " + driver.getCurrentUrl());
			
		driver.switchTo().window( addr.get(0) ); // Here Selenium Attention jump on Main Page
		System.out.println("-------------------------------");
		System.out.println("Address of Main Page => " + driver.getWindowHandle());
		System.out.println("Url of MainPage => " + driver.getCurrentUrl());
	
	
	}
/*
 		# getWindowHandle();
 		--> It is Non-Static Method.
 		--> Argument 	=> zero
 		--> ReturnType  => String.
 		--> Source 		=> Webdriver.
 		--> purpose		=> It is gives address of an Main Browser window/Tab.
 		
 		# getWindowHandles();
 		--> It is Non-Static Method.
 		--> Argument 	=> zero
 		--> ReturnType  => Set<String>
 		--> Source 		=> Webdriver.
 		--> purpose		=> It is gives address of an 
 							Main Browser window/Tab
 										+
 						All Child Browser Opened By Main Page.
 						
 		# switchTo();
 		--> It is Non-Static Method.
 		--> Argument 	=> zero
 		--> ReturnType  => TargetLocator
 		--> Source 		=> Webdriver.
 		--> purpose		=> It is used to move attention of selenium on target.
 		
 			# window();
 		--> It is Non-Static Method.
 		--> Argument 	=> String nameOrHandle
 		--> ReturnType  => Webdriver
 		--> Source 		=> TargetLocator
 		--> purpose		=> ---
 		
 		
 */
}
