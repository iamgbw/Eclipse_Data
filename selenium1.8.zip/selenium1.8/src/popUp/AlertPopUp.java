package popUp;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertPopUp {
	
	public static void main(String[] args) throws InterruptedException 
	{
			
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("http://demo.guru99.com/test/delete_customer.php");
		  	Thread.sleep(3000);
		  	
		  	driver.manage().window().maximize();
		  	Thread.sleep(3000);
		  	
		  	WebElement submit = driver.findElement(By.xpath("//input[@name='submit']"));
		  	
		  	submit.click();
		  	Thread.sleep(3000);
		  	
		  	Alert alt = driver.switchTo().alert();
		  	Thread.sleep(3000);
		  	
		  	String text = alt.getText();	// To get Text present on Alert popup
		  	System.out.println(text);
		  	Thread.sleep(3000);
		  	
		  	alt.accept(); 	// To click on OK, YES, Continue, Accept, Submit
		  
//		  	alt.dismiss();	// To click on Cancel, No, Dismiss		
//		  	alt.sendKeys("Ram!Ram!!Ram!!!");
	
		  	alt = driver.switchTo().alert();
		  	Thread.sleep(3000);
		  	
		  	alt.accept();
	}

}
