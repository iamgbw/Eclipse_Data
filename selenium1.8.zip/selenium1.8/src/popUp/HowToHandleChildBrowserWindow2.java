package popUp;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HowToHandleChildBrowserWindow2 {
	
	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver",
			"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
	
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
	
		driver.get("https://www.w3schools.com/js/js_popup.asp");
		Thread.sleep(2000);
		System.out.println("Address of Main Page => " + driver.getWindowHandle());
		System.out.println("Url of MainPage => " + driver.getCurrentUrl());
		System.out.println("-------------------------------");
	
		WebElement alert = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));
		alert.click();
		
		ArrayList<String> addr = new ArrayList<String>( driver.getWindowHandles() );
		int sizeOfaddr = addr.size();
		System.out.println(sizeOfaddr);
		System.out.println("-------------------------");
		
		for(int i = 0 ; i <= (sizeOfaddr-1) ; i++)
		{
			System.out.println( addr.get(i) );
		}
		
		System.out.println("-------------------------");

		driver.switchTo().window(addr.get(1));
		WebElement getYourWebsite = driver.findElement(By.xpath("//a[@id='getwebsitebtn']"));
		getYourWebsite.click();
		
		ArrayList<String> addr1 = new ArrayList<String>( driver.getWindowHandles() );
		int sizeOfaddr1 = addr1.size();
		System.out.println(sizeOfaddr1);
		System.out.println("-------------------------");
		
		for(int i = 0 ; i <= (sizeOfaddr1-1) ; i++)
		{
			System.out.println( addr1.get(i) );
		}
		
	}
}
