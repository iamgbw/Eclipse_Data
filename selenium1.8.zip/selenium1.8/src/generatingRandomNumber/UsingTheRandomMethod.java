package generatingRandomNumber;

public class UsingTheRandomMethod {
	int i;
	public static void main(String args[])   
	{   
	// Generating random numbers  
	System.out.println("1st Random Number: " + Math.random());   
	System.out.println("2nd Random Number: " + Math.random());  
	System.out.println("3rd Random Number: " + Math.random());   
	System.out.println("4th Random Number: " + Math.random());   
	
/*
 	# Math => Is a Class.
 	# random(); => Is a static method of Math Class
 */
	System.out.println("-------------------------------");
	
	int max = 10;
	int min = 1;
	System.out.println("Random value of type int between "+min+" to "+max+ ":");  
	int b = (int)(Math.random()*(max-min+1)+min);  
	System.out.println(b);
	
	System.out.println("-------------------------------");

	for(int i = 1 ; i < 5 ; i++)
	{
//		int max = 9;
//		int min = 2;
		System.out.println("Random value of type int between "+min+" to "+max+ ":");  
		i = (int)(Math.random()*(max-min+1)+min);  
		System.out.println(i);	
	}
	
	}  
}
