package TakesScreenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class getScreenshotAsMethod {

	public static void main(String[] args) throws InterruptedException, IOException 
	{
			
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("https://www.facebook.com/");
		  	Thread.sleep(3000);
		  	
		  	// How to Take Screenshot in Selenium of any failed TestCase //
		  	
		  	File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		  	File dest = new File("C:\\ProgrammUse\\Test123.jpg");
		  	
		  	FileHandler.copy(source, dest);
		  	
/*	
	# TakesScreenshot => is a interface from Selenium library.
	# driver => is object of a ChromeDriver Class.
	# OutputType => is a Interface.
	# FILE => is a static variable of OutputType Class.
	# OutputType.FILE => is a static variable call.
	# File => Is a Class.
	# source => is a object ref. variable where,
	  "getScreenshotAs()" method save captured image temprory.
	# dest => is a object(file path argument object) ref. variable where,
	  we save captured image by using "copy()" method of FileHandler Class.
	# FileHandler is Class in Selenium Library.
	
	# copy();
	--> Is a Static method of FileHandler Class.
	--> Argument => Object Double Argument
	--> ReturnType => Void
	--> Purpose => To copy file from source to dest.
	
	# getScreenshotAs();
	--> Is a non-static method of TakesScreenshot interface.
	--> Argument => OutputType.FILE (is a static variable call)
	--> ReturnType => source (object ref. variable)
	--> Purpose => Is used to capture a Screenshot.
*/
		  	System.out.println("--------------");
/*
 				?? HomeWork ??
 -----> for loop

 1. add loop variable in image name
 2. add random number in image name 
 	--> Google Search => (how to generate random number in java)
 3. add system date & time in image name 
 	--> Google Search => (how to fetch system date in java)
 	-----> Thread.sleep - 1000
 	01/02/2022 09:02:14  --> replace '/' to '-'
 */
 
	}
}
