package TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Example3 {
	public static void main(String[] args) throws InterruptedException, IOException 
	{
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("https://www.facebook.com/");
		  	Thread.sleep(3000);
		  	
		  	System.out.println("------------------------");
		
		  		// Fetch SystemDate & Time //
//		  	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
//			LocalDateTime now = LocalDateTime.now();  
//			System.out.println(dtf.format(now));
//		  	System.out.println("------------------------");
//		  	
//		  	 String a = dtf.format(now);
//			 System.out.println(a);
//			 System.out.println("------------------------");
//			 
//			 String s =a.replace('/', '-');
//			 System.out.println(s);
//			 System.out.println("------------------------");

		  	/* How to Take Multiple Screenshot named as date and time
		  	 		in Selenium of any failed TestCase */
		  	
		  	for (int i = 1 ; i < 5 ;i++ )
		  	{
		  	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println(dtf.format(now));
			System.out.println("------------------------");
			
		  	String a = dtf.format(now);
			System.out.println(a);
			System.out.println("------------------------");
					 
			String s =a.replace('/', '-');
			System.out.println(s);
			System.out.println("------------------------");
			
		  	File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		  	File dest = new File("C:\\Users\\Lenovo\\Screenshots\\Test" + s + ".jpg");
		  	
		  	System.out.println(i);
		  	Thread.sleep(3000);
		  	
		  	FileHandler.copy(source, dest);
		  	}
	}
}
