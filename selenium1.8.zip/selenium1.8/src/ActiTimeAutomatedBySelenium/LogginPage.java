package ActiTimeAutomatedBySelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogginPage {

public static void logginPage throws InterruptedException 
{
		
		System.setProperty("webdriver.chrome.driver", 
			"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.get("http://localhost/login.do");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		Thread.sleep(3000);
		WebElement keepMeloggedIn = driver.findElement(By.xpath("//input[@type='checkbox']"));
		keepMeloggedIn.click();
		Thread.sleep(3000);
		keepMeloggedIn.click();
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
	}
}
