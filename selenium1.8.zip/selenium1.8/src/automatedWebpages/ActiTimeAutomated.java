package automatedWebpages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class ActiTimeAutomated {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
			"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		
		// LoggIn Page //
		driver.get("http://localhost/login.do");
		//Thread.sleep(3000);
		System.out.println( driver.getTitle() );
	//	Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
//		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		//Thread.sleep(3000);
		WebElement keepMeloggedIn = driver.findElement(By.xpath("//input[@type='checkbox']"));
		keepMeloggedIn.click();
		Thread.sleep(3000);
	//	keepMeloggedIn.click();
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
//		Thread.sleep(3000);
		// Tasks //
		driver.findElement(By.xpath("(//td[@class='navItem relative'])[2]")).click();
		Thread.sleep(3000);
		String text = driver.findElement(By.xpath("(//th[@nowrap='1'])[1]")).getText();
		System.out.println("$" + text + "$");
		
		String text1 = driver.findElement(By.xpath("(//th[@nowrap='1'])[6]")).getText();
		System.out.println("$" + text1 + "$");
		System.out.println("Last Tracking\r\n"
				+ "Date");
		String text2 = driver.findElement(By.xpath("(//th[@nowrap='1'])[7]")).getText();
		System.out.println("$" + text2 + "$");
		//driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
		
		
		
		
//		
//		
//						// Enter Time-Track //
//		
//			//////////////////////////////// Enter Time-Track //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//		
//		
////		driver.findElement(By.xpath("//a[text()='Enter Time-Track']")).clear();
////		Thread.sleep(3000);
//		
//		WebElement createNewTasksN = driver.findElement(By.xpath("//span[text()='New']"));
//		createNewTasksN.click();
//		Thread.sleep(3000);
//		
////		driver.switchTo().window("createTasksPopup");
///*	As we can inspect element present in "Hidden-Division Popup",
//   	then using selenium we can handle it & 
//   	No Need to switch.
//*/		
//		driver.findElement(By.xpath("//button[text()='- Select Customer -']")).click();
//		Thread.sleep(3000);
//		
//		Actions act = new Actions(driver);
//
//		
//		WebElement newCust1 = driver.findElement(By.xpath("(//li[contains(@id,'ext-gen')])[2]"));
//		act.moveToElement(newCust1).click().build().perform();
//		Thread.sleep(3000);
//		
//		driver.findElement(By.xpath("//input[@placeholder='Enter Customer Name']")).sendKeys("Royal Nagesh Kapse");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//input[@placeholder='Enter Project Name']")).sendKeys("Aadhyaksha");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[1]")).sendKeys("Round Marane");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[2]")).sendKeys("Royal rahane");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[3]")).sendKeys("Nahi Mahit");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//span[text()='Create Tasks']")).click();
//		
////		
////		driver.findElement(By.xpath("//input[@placeholder='Enter Customer Name']")).sendKeys("Isha Yoga Center");
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("//input[@placeholder='Enter Project Name']")).sendKeys("Mahashivratri");
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[1]")).sendKeys("Bhajan");
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[2]")).sendKeys("Classical Dance");
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("(//input[@placeholder='Enter task name'])[3]")).sendKeys("Mirvnuk");
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("//span[text()='Create Tasks']")).click();
//		
//		WebElement error = driver.findElement(By.xpath("//div[contains(text(),'Customer with this name already exists. P')]"));
//		boolean result = error.isDisplayed();
//		System.out.println(result);
//		Thread.sleep(3000);
//		
//		if(result = true )
//		{
//			driver.findElement(By.xpath("//div[text()='Cancel']")).click();
//		}
//		else
//		{
//			System.out.println("Check Again");
//		}
//		
//		Alert alert = driver.switchTo().alert();
//		alert.accept();
//		
//		
		
		
		
		
		////////////////////////////// Tasks \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
	}

}
