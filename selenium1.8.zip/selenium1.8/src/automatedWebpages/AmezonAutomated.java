package automatedWebpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class AmezonAutomated {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
		
		
		
		
		////////////////////////////////// Header \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
		
		//# Amezon Logo
		WebElement logo = driver.findElement(By.xpath("//div[@id='nav-logo']"));
		logo.click();
		Thread.sleep(3000);
		driver.navigate().back();
		
		//# Address
		driver.findElement(By.xpath("//div[@id='nav-global-location-slot']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@aria-label='or enter an Indian pincode']")).sendKeys("313918");
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//input[@type='submit'])[4]")).click();
		Thread.sleep(3000);
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		//# SearchBox
		WebElement descript = driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
		descript.click();
		Thread.sleep(3000);
		Select s = new Select(descript);
		s.selectByValue("search-alias=alexa-skills");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Java Book");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		Thread.sleep(3000);
		
		// #Language
		driver.findElement(By.xpath("//a[@id='icp-nav-flyout']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Cancel']")).click();
		Thread.sleep(3000);
		
		// #Account & List
		WebElement accAndList = driver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
		Actions act = new Actions(driver);
		act.moveToElement(accAndList).perform();
		Thread.sleep(3000);
		
				// => Login
		WebElement signIn = driver.findElement(By.xpath("(//a[@data-nav-role='signin'])[2]"));
		signIn.click();
		Thread.sleep(3000);
		driver.navigate().back();
		
				// => Your Account
		WebElement urAcc = driver.findElement(By.xpath("//span[text()='Your Account']"));
		act.moveToElement(urAcc).click().build().perform();
		Thread.sleep(3000);
		driver.navigate().back();
		System.out.println("---------");

	
		// #Cart 
		WebElement cart = driver.findElement(By.xpath("//a[@id='nav-cart']"));
		cart.click();
		Thread.sleep(3000);
		driver.navigate().back();
		
		////////////////////////////////// SignIN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
		
		// #username
		WebElement username = driver.findElement(By.xpath("//input[@name='email']"));
		username.sendKeys("9860485758");
		Thread.sleep(3000);
		
		// #continue/ logIN
		WebElement logIN = driver.findElement(By.xpath("//span[@id='continue']"));
		logIN.click();
		Thread.sleep(3000);
		driver.navigate().back();
		
		// #password
		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("India@11");
		Thread.sleep(3000);
		
		// #signIn
		WebElement signInToYourAccount = driver.findElement(By.xpath("//input[@id='signInSubmit']"));
		signInToYourAccount.click();
	}

}
