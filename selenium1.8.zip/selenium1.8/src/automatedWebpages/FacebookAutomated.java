
package automatedWebpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class FacebookAutomated {
	

	public static void main(String[] args) throws InterruptedException 
	{
			
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("https://www.facebook.com/");
		  	Thread.sleep(5000);
		  	
		    driver.manage().window().maximize();
		    Thread.sleep(3000);
		  	
		  	WebElement email = driver.findElement(By.id("email"));
		  	email.sendKeys("Ram!Ram!!Ram!!!");
		  	Thread.sleep(3000);
		
		  	WebElement password = driver.findElement(By.id("pass"));
		  	password.sendKeys("123456789");
		  	Thread.sleep(3000);
		  	driver.findElement(By.xpath("//div[@class='_9lsa']")).click();
		  	Thread.sleep(3000);
		  	
		  	WebElement login = driver.findElement(By.xpath("//button[text()='Log In']"));
		  	login.click();
		  	Thread.sleep(3000);
		  			  	
		  	driver.navigate().back();
		  	Thread.sleep(3000);
		  	
		  	WebElement forgottenAccount = driver.findElement(By.xpath("//a[text()='Forgotten password?']"));
		  	forgottenAccount.click();
		  	Thread.sleep(3000);
		  	
		  	driver.navigate().back();
		  	Thread.sleep(3000);
		  	
			WebElement createNewAccount = driver.findElement(By.xpath("//a[contains(text(),'te N')]"));
			createNewAccount.click();
		  	Thread.sleep(3000);
		  	
		  	driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Ganesh");
		  	Thread.sleep(5000);
		  	driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Waghmare");
		  	Thread.sleep(5000);
		  	driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("Ganesh cha email");
		  	Thread.sleep(5000);
		  	driver.findElement(By.xpath("//input[@name='reg_passwd__']")).sendKeys("9876543210");
		  	
		  	/* 1) selectByIndex */
		  	WebElement Day = driver.findElement(By.xpath("//select[@id='day']"));
		  	Select s1 = new Select(Day);
		  	s1.selectByIndex(23);
		  	Thread.sleep(3000);
		  	
		  	/* 2) selectByValue */ 
		  	WebElement month = driver.findElement(By.xpath("//select[@id='month']"));
		  	Select s2 = new Select(month);
		  	s2.selectByValue("8");
		  	Thread.sleep(3000);
		  	
		  	/* 3) selectByVisibleText */
		  	WebElement year = driver.findElement(By.xpath("//select[@id='year']"));
		  	Select s3 = new Select(year); 
		  	s3.selectByVisibleText("1994");
		  	
		  	driver.findElement(By.xpath("//label[text()='Custom']")).click();
		  	Thread.sleep(3000);
		    WebElement selectUrPronoun = driver.findElement(By.xpath("//select[@aria-label='Select your pronoun']"));
		    selectUrPronoun.click();
		  	Thread.sleep(3000);
		  	Select s4 = new Select(selectUrPronoun);
		  	s4.selectByValue("1");
		  	Thread.sleep(3000);
		  	
		  	driver.findElement(By.xpath("//input[@aria-label='Gender (optional)']")).sendKeys("Mangalam Bhagwan Vishnu");
		  	Thread.sleep(3000);
		  	
		  	driver.findElement(By.xpath("//label[text()='Female']")).click();
		  	Thread.sleep(3000);
		  	
		  	driver.findElement(By.xpath("//label[text()='Male']")).click();
		  	Thread.sleep(3000);
		  	
		  	WebElement submit = driver.findElement(By.xpath("(//button[@type='submit'])[2]"));
		  	submit.click();
	}
}
