package htmlTale;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Homework {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver =new ChromeDriver();
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		
		List<WebElement> rows = driver.findElements(By.xpath("//table[@id='customers']//tr"));
		int noOfRows = rows.size();
		System.out.println(noOfRows);
		
		List<WebElement> cells = driver.findElements(By.xpath("(//table[@id='customers']//tr)[1]//th"));
		int cell = cells.size();
		System.out.println(cell);
		for(int i = 0 ; i < cell ; i++)
		{
			WebElement box = cells.get(i);
			String c = box.getText();
			System.out.print(c);
			System.out.print(",");
		}
		System.out.println();
		
		for(int i = 2 ; i <= noOfRows ; i++ )
		{
			List<WebElement> cells1 = driver.findElements(By.xpath("(//table[@id='customers']//tr)["+i+"]//td"));
			int cell1 = cells.size();
			for(int j = 0 ; j < cell1 ; j++)
			{
				WebElement box = cells1.get(j);
				String c = box.getText();
				System.out.print(c);
				System.out.print(",");
			}
			System.out.println();
		}
		
		
		
		System.out.println("Ram");
	
		
	}
}
