package iframe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IFrame1 {

	public static void main(String[] args) throws InterruptedException {
	
	System.setProperty("webdriver.chrome.driver", 
	"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
	WebDriver driver= new ChromeDriver();
	
	//driver.manage().window().maximize();
	
	driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_myfirst");
	Thread.sleep(1000);
	
	driver.switchTo().frame("iframeResult");
	Thread.sleep(1000);
	
	
	driver.findElement(By.xpath("//button[@type='button']")).click();
	}
	
/* 		--> First of all we have to switch Selenium Attention on this Iframe.
		--> It can be done B using below Three Method's.
		1) Index of Iframe (int)---> In Nested Index it will complex, we avoid it to use.
		2) ID/Name of Frame (String)
		3) WebElement of Iframe (WebElement)
		
*/
}
