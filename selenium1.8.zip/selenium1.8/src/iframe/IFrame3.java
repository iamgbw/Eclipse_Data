package iframe;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IFrame3 {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
		"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
	
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
		Thread.sleep(3000);
		

		// 2) ID/Name of Frame (String)
		
		WebDriver frame = driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		WebElement tryIt = driver.findElement(By.xpath("//button[@onclick='myFunction()']"));

		tryIt.click();

		Thread.sleep(3000);
		
		Alert alt = frame.switchTo().alert();
		alt.accept();
		Thread.sleep(3000);
		
		// Switch to Parent Frame Only
		driver.switchTo().parentFrame();
		String url = driver.getCurrentUrl();
		System.out.println(url);
	}

}
