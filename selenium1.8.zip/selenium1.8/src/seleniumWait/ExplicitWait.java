package seleniumWait;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWait {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.w3schools.com/js/js_popup.asp");

//		WebElement alert 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));

		
		WebDriverWait wait = new WebDriverWait(driver, 20);		//20 sec waiting time
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[text()='Try it Yourself �'])[2]")));
		
		
//		WebElement confirm 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[2]"));
//		
//		WebElement prompt		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[3]"));
//		
//		WebElement lineBreaks   = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[4]"));
		
	}

}
