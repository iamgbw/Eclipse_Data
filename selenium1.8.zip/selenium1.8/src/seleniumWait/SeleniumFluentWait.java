package seleniumWait;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class SeleniumFluentWait {
	
public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.w3schools.com/js/js_popup.asp");

		Wait<WebDriver> wait = new  FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(20))		// Maximum waiting Time
				.pollingEvery(Duration.ofMillis(100))		// Frequency to check an condition
				.ignoring(NoSuchElementException.class);	// condition
		
		WebElement trIitYourself = (WebElement)  wait.until(new Function<WebDriver, WebElement>() {
			
			public WebElement apply(WebDriver driver)
			{
				WebElement ele = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));
				return ele;
			}
			
		});
		
		trIitYourself.click();
	}
}
