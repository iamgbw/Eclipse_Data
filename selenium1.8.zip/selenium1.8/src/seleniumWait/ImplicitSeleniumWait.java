package seleniumWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitSeleniumWait {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		
		WebDriver driver = new ChromeDriver();
		
		// Implicit Wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//*				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.w3schools.com/js/js_popup.asp");

//		WebElement alert 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[1]"));
//
//		WebElement confirm 		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[2]"));
//		
//		WebElement prompt		= driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[3]"));
//		
//		WebElement lineBreaks   = driver.findElement(By.xpath("(//a[text()='Try it Yourself �'])[4]"));
		
	}

}
