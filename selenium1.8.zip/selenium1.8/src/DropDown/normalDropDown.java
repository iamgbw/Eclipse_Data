package DropDown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class normalDropDown {
	
	public static void main(String[] args) throws InterruptedException 
	{
			
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
						
			Thread.sleep(5000);
			
			driver.get("https://www.facebook.com/");
		  	Thread.sleep(3000);
		  	
		  	driver.manage().window().maximize();
		  	Thread.sleep(3000);
		  	
		  	WebElement creatNewAcc = driver.findElement(By.xpath("//a[contains(text(),'te N')]"));
		  	creatNewAcc.click();
		  	Thread.sleep(3000);
		  	
		
/*
 		# Type's of DropDown:-
 			1) Normal Drop-Down 
 			=> Which has 'select' Tagname
 			=> Here we use Select class method's
 			
 			2) Customized Drop-Down:-
 			=> Which has no select Tagname
 			=> Here we not use Select Class method's
 		
 # Here Select is Class which has WebElement Argument Type Constructor.
 #To Handle normalDrop-Down We use below three Different method's:-
 		1) selectByIndex();
 		2) selectByValue();
 		3) selectByVisibleText(); 		
*/
		  	/* 1) selectByIndex */
		  	WebElement Day = driver.findElement(By.xpath("//select[@id='day']"));
		  	Select s1 = new Select(Day);
		  	s1.selectByIndex(23);
		  	Thread.sleep(3000);
		  	
		  	/* 2) selectByValue */ 
		  	WebElement month = driver.findElement(By.xpath("//select[@id='month']"));
		  	Select s2 = new Select(month);
		  	s2.selectByValue("8");
		  	Thread.sleep(3000);
		  	
		  	/* 3) selectByVisibleText */
		  	WebElement year = driver.findElement(By.xpath("//select[@id='year']"));
		  	Select s3 = new Select(year); 
		  	s3.selectByVisibleText("1994");
		  	}
}
