package mouseAction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseActionmoveToElement {

	public static void main(String[] args) throws InterruptedException {
		
	System.setProperty("webdriver.chrome.driver", 
			"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("https://www.amazon.in/");
	WebElement accAndList = driver.findElement(By.xpath("//span[contains(text(),'t & L')]"));
	
	Actions act = new Actions(driver);
	
	//act.moveToElement(accAndList).click().build().perform();
	
	act.moveToElement(accAndList);
	Thread.sleep(3000);
	act.click();
	Thread.sleep(3000);

	act.perform();
	
	}
	
/*
 	#Actions class methods :-
 1. click ();			 => Left click on the Element.
 2. perform();			 => To perform/execute the Action on Element.
 3. moveToElement();	 => Used to move pointer on Element.
 4. build();			 => When multiple action perform/call
 							in single(same) Line then use build. 
 5. doubleclick() 		 => Left double click on element.
 6. contextClick();		 => Right Click 
 7. dragAndDrop();		 => drag one element and drop the same element at other place 
 8. clickAndHold();		 => click and hold 
 9. release();			 => release the click and hold element. 
 
*/
}
