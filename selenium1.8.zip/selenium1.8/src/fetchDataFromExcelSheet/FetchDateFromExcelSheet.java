 
package fetchDataFromExcelSheet;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.ss.usermodel.WorkbookFactory;

public class FetchDateFromExcelSheet {
	
	public static void main(String[] args) throws IOException {
		
		String path = "C:\\ProgrammUse\\Test.xlsx";
		
		FileInputStream file = new FileInputStream(path);
		
		Date value = WorkbookFactory.create(file).getSheet("Velocity 20 Nov-A").getRow(108).getCell(3).getDateCellValue();

		System.out.println(value);
				
/*
 				|| Fetch Data From ExcelSheet ||
 	# FileInputStream is a Class. 
 	# FileInputStream is a Implementation Class of InputStream Interface.
 	# Constructor of FileInputStream Class is String Argument.
 	# WorkbookFactory is a Class.
 	
 	# create();
 	--> It is a static method of WorkbookFactory.
 	--> Argument => object of FileInputStream Class.
 	--> ReturnType => Workbook
 	--> Source => WorkbookFactory
 	--> Purpose => Is used to open file for jvm.
 	
 	# getSheet();
 	--> It is a Non-Static Method.
 	--> Argument => String (i.e. Sheet Name)
 	--> ReturnType => Sheet
 	--> Source => Workbook
 	--> Purpose => Is used to select the Sheet from Excel file
 	
 	# getRow();
 	--> It is a Non-Static Method.
 	--> Argument => int
 	--> ReturnType => Row
 	--> Source => Sheet
 	--> Purpose => Is used to select Row from Selected Sheet
 	
 	# getCell();
 	--> It is a Non-Static Method
 	--> Argument => int 
 	--> ReturnType => Cell
 	--> Source => Row
 	--> Purpose => Is used to select Cell from Selected Row
 	
 	# getDateCellValue();
 	--> It is a Non-Static Method
 	--> Argument => zero 
 	--> ReturnType => Date
 	--> Source => Cell
 	--> Purpose => Is used to copy date from Selected Cell to use in Program.	
*/
	}
}
