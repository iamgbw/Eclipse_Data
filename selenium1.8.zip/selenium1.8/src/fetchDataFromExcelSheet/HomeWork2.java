package fetchDataFromExcelSheet;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class HomeWork2 {
	
	public static String fetchDataFromExcelSheet(String sheetname, int n, int m) throws IOException
	{
		String path = "C:\\ProgrammUse\\Test.xlsx";
		
		FileInputStream file = new FileInputStream(path);
		
		 Workbook workbook = WorkbookFactory.create(file);
		 Sheet sheet = workbook.getSheet("Friend1");
		 Row row = sheet.getRow(n);
		 Cell cell = row.getCell(m);		
		 String Value =	cell.getStringCellValue();
		 System.out.println(Value);
		
		 //workbook.close(); //used to close file which is opened for jdk -->returnType= void
		return Value;
	}
	
	public static void main(String[] args) throws IOException  {
		
		HomeWork2.fetchDataFromExcelSheet("Friend1", 1, 1);
		System.out.println("---------------------------------");
		fetchDataFromExcelSheet("Friend1", 1, 2);
	}

}
