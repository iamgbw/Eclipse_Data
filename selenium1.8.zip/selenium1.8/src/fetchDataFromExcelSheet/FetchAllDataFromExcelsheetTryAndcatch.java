package fetchDataFromExcelSheet;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class FetchAllDataFromExcelsheetTryAndcatch {

public static void main(String[] args) throws IOException {
		
		String path = "C:\\ProgrammUse\\Test.xlsx";
		
		FileInputStream file = new FileInputStream(path);
		
		
		//Cell cell = 
		Sheet sheet = WorkbookFactory.create(file).getSheet("Velocity 20 Nov-A");
		
		int Lrow = sheet.getLastRowNum();
		
		for (int i = 0 ; i <= Lrow ; i++)
		{
			Row n = sheet.getRow(i);
			
			int Lcell = n.getLastCellNum();

			for(int j = 0; j < Lcell ; j++)
			{
				Cell cell = n.getCell(j);
				//System.out.print(cell.getStringCellValue());
				 try
				 {
					 String stringValue =  cell.getStringCellValue();
					 System.out.print(stringValue);
				 }
				 catch(IllegalStateException numericValue)
				 {
					 double numValue = cell.getNumericCellValue();
					 System.out.print(numValue);
				 }
				 catch(NullPointerException nullValue)
				 {
					 System.out.print("------------");
				 }
				System.out.print("               ");			
			}
			System.out.println();
		}
		
		
		
		// .getRow(8).getCell(4);
		
		
//		 try
//		 {
//			 String stringValue =  cell.getStringCellValue();
//			 System.out.println(stringValue);
//		 }
//		 catch(IllegalStateException numericValue)
//		 {
//			 double numValue = cell.getNumericCellValue();
//			 System.out.println(numValue);
//		 }
//		 catch(NullPointerException nullValue)
//		 {
//			 System.out.println("Null Cell");
//		 }
		
		
		
	}
}
