package fetchDataFromExcelSheet;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Homework3 {

	public String fetchDataFromExcelSheet(String sheetname, int n, int m) throws IOException
	{
		String path = "C:\\ProgrammUse\\Test.xlsx";
		
		FileInputStream file = new FileInputStream(path);
		
		 Workbook workbook = WorkbookFactory.create(file);
		 Sheet sheet = workbook.getSheet("Friend1");
		 Row row = sheet.getRow(n);
		 Cell cell = row.getCell(m);		
		 String Value =	cell.getStringCellValue();
		 System.out.println(Value);
		
		return Value;
	}
	
	public static void main(String[] args) throws IOException  {
		
		Homework3 H3 = new Homework3();
		H3.fetchDataFromExcelSheet("Friend1", 2, 2);
		
	}
}
