package fetchDataFromExcelSheet;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class HomeWork1 {
	
public static void main(String[] args) throws IOException {
		
		String path = "C:\\ProgrammUse\\Test.xlsx";
		
		FileInputStream file = new FileInputStream(path);

		Sheet sheet = WorkbookFactory.create(file).getSheet("Friend2");

		int Lrow = sheet.getLastRowNum();
	
		for (int i = 0 ; i <= Lrow ; i++)
		{
			Row n = sheet.getRow(i);
			
			int Lcell = n.getLastCellNum();

			for(int j = 0; j < Lcell ; j++)
			{
				Cell cell = n.getCell(j);
				System.out.print(cell.getStringCellValue());
				System.out.print("          ");			
			}
			System.out.println();
		}
	}
/*
	# getLastRowNum();
	--> This is Non-Static Method.
	--> Argument => zero
	--> ReturnType => int
	--> Source => Sheet
	--> Purpose => To get Last row number from table of selected Sheet.
	
	# getLastCellNum();
	--> This is Non-Static Method.
	--> Argument => zero
	--> ReturnType => long (But it can be 'int' by using Casting automatically)
	--> Source => Row
	--> Purpose => To get Last Cell number from table of selected Sheet
*/
}
