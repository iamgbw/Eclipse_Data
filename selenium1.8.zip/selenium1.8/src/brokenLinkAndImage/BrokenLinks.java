package brokenLinkAndImage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrokenLinks 
{
		public static void main(String[] args) throws InterruptedException 
		{
				
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Lenovo\\Downloads\\exeFile's\\chromedriver.exe");
				WebDriver driver= new ChromeDriver();
				Thread.sleep(2000);
				
				driver.get("https://www.w3schools.com/html/html_tables.asp");
				Thread.sleep(2000);
			
				
				// How to verify broken links
				
				List<WebElement> links = driver.findElements(By.tagName("a"));
				int totalLinks = links.size();
				System.out.println(totalLinks);
				
				for(int i=0; i< totalLinks; i++) 
				{
					
						WebElement element = links.get(i);
						String link = element.getText();
						
						if(link.equals(null)) 
						{
							System.out.println("This link is broken-----"+i);
						}
						else 
						{	
							System.out.println(link); //there are no broken link's therefore else block executed
						}				
				}	

		}	
}

