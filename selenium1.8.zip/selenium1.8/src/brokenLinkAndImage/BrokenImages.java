package brokenLinkAndImage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrokenImages {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Lenovo\\Downloads\\exeFile's\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Thread.sleep(2000);
		
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		Thread.sleep(2000);
		
		 Integer iBrokenImageCount = 0;
		 String status = "";
		 
	        try
	        {
	            iBrokenImageCount = 0;
	            List<WebElement> image_list = driver.findElements(By.tagName("img"));
	            /* Print the total number of images on the page */
	            System.out.println("The page under test has " + image_list.size() + " images");
	            for (WebElement img : image_list)
	            {
	                if (img != null)
	                {
	                    if (img.getAttribute("naturalWidth").equals("0"))
	                    {
	                        System.out.println(img.getAttribute("outerHTML") + " is broken.");
	                        iBrokenImageCount++;
	                    }
	                }
	            }
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	            status = "failed";
	            System.out.println(status);
	            System.out.println(e.getMessage());
	        }
	        status = "passed";
	        System.out.println(status);
	        System.out.println("The page "  + " has " + iBrokenImageCount + " broken images");
	}
}
