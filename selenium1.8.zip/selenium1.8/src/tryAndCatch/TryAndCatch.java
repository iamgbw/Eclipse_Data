package tryAndCatch;

public class TryAndCatch {

	public static void main(String[] args) {
		
		int a = 12;
		int b = 0;
		int c;
		
		int d [] = {12, 8, 54, 85, 42};
		
		try
		{
			c = a/b;
			System.out.println("Hi");
			System.out.println(c);
			System.out.println(d[8]);
		}
		
		catch( ArithmeticException arithmatic ) {
			
			arithmatic.printStackTrace();
			
			System.out.println(" b is zero");
		}
		
		System.out.println("END");
	}
}
