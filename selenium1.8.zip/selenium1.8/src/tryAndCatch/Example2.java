package tryAndCatch;

public class Example2 {

	public static void main(String[] args) {
		

		int a = 12;
		int b = 0;
		int c = 0;
		
		int d [] = {12, 8, 54, 85, 42};
		
		try 
		{
			c= a/b;
			System.out.println("Hi");
			try
			{
				System.out.println(d[7]);
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Alternative Code");
			}
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
		
		System.out.println("c = " + c);
	}
}
