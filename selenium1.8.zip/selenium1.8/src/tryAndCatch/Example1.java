package tryAndCatch;

public class Example1 {

public static void main(String[] args) {
		
		int a = 12;
		int b = 2;
		int c;
		
		int d [] = {12, 8, 54, 85, 42};
		
		try
		{
			c = a/b;
			System.out.println("Hi");
			System.out.println(c);
			System.out.println(d[8]);
		}
		
		catch( ArithmeticException arithmatic ) {
			System.out.println(" b is zero");
			arithmatic.printStackTrace();
		}
		
		catch(ArrayIndexOutOfBoundsException arrayIndexBound)
		{
			System.out.println("Array index is not present");
			arrayIndexBound.printStackTrace();
		}
		
		System.out.println("END");
	}
}
