package tryAndCatch;

public class Example3 {

	public static void main(String[] args) {

		int a = 12;
		int b = 2;
		int c = 5;
		
		int d [] = {12, 8, 54, 85, 42};
		
		try 
		{
			System.out.println("try");
			c= a/b;
			System.out.println(d[9]);
		}
		catch(ArithmeticException arth)
		{
			System.out.println("Catch Block");
		}
		finally
		{
			System.out.println("finally");
		}
		System.out.println("c = " + c);
		
	}
}
