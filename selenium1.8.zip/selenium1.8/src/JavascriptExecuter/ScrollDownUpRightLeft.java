package JavascriptExecuter;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollDownUpRightLeft {

	public static void main(String[] args) throws InterruptedException {
		
	System.setProperty("webdriver.chrome.driver", 
			"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("https://srjbtkshetra.org/");
	Thread.sleep(2000);
	
	driver.manage().window().maximize();
	Thread.sleep(3000);
	
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	js.executeScript("window.scroll(0, 5000)");		// Scroll Down
	Thread.sleep(3000);
	
	// Practically Not in Use
	js.executeScript("window.scroll(0, 1000)");		// Scroll up
	
	// Practically Not in Use
//	js.executeScript("window.scroll(1000, -1000)");	// Scroll Right
//
//	js.executeScript("window.scroll(500, -1000)");	// Scroll Left
	
	}
}
