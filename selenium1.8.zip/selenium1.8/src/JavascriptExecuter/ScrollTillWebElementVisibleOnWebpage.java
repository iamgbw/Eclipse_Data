package JavascriptExecuter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollTillWebElementVisibleOnWebpage {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.isro.gov.in/");
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		WebElement isroLogo = driver.findElement(By.xpath("//img[@alt='ISRO']"));
		//WebElement nationalEmblem = driver.findElement(By.xpath("//img[@alt='National Emblem']"));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true)", isroLogo);
	    
		Thread.sleep(3000);
		
		// js.executeScript("arguments[0].scollIntoView(true)", nationalEmblem);
		
		/*
		 # scollIntoView(); => it can not scroll Up & Below Exception occurs
		 # org.openqa.selenium.JavascriptException: javascript error: arguments[0].scollIntoView is not a function
		*/
		
		isroLogo.click();
	}
}
