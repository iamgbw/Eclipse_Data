package constructor;							// Declaration of package		
public class Example1 							// Declaration of class
{
	static int a = 47 ;							// static varible 'a' Declaration and initialisation
	 int b = 45;								// Non-static varible 'b' Declaration and initialisation
	
	 Example1()									// zero argument constructor Declaration 
	{
		 a = 10;
		 b = 20;
	}
	
	Example1(int n)								// single argument constructor Declaration
	{
		 a = 30;
		 b = 40;
	}
	
	Example1(int g, char f)						// double argument constructor Declaration
	{
		 a = 50;
		 b = 60;
	}								
	public static void main(String[] args) 	// main method calling
	{	
		System.out.println(a);				// static variable 'a' can call directly without argument---> o/p--> a = 47
		System.out.println(Example1.a);		// static variable 'a' can call as "classname.staticvariablename" without argument
													//----------> o/p--> a = 47
											// static variable 'a' can also call as "ObjVar.staticvariablename"
		
		
		Example1 d = new Example1();		// zero argument constructor calling to call non-static variable 'b'--->obj. ref. is 'd'
		 System.out.println(d.b);			// non-static elements can call only by using object reference variable
		 									// AND after calling constructor--> object 'd' load variable b = 20 
		 
		Example1 q = new Example1();		// zero argument constructor calling to call non-static variable 'b'--->obj. ref. is 'q'
		System.out.println(a);				// after calling constructor--> object 'q' load variable a = 10
		System.out.println(q.b);			// after calling constructor--> object 'q' load variable b = 20
		
		
		Example1 o = new Example1(54);		// single argument constructor calling to call non-static variable 'b'--->obj. ref. is 'o'
		System.out.println(a);				// after calling constructor--> object 'o' load variable a = 30
		System.out.println(o.b);			// after calling constructor--> object 'o' load variable b = 40
		
		
		Example1 m = new Example1(74, '@');	// double argument constructor calling to call non-static variable 'b'--->obj. ref. is 'm'
		System.out.println(a);				// after calling constructor--> object 'm' load variable a = 50
		System.out.println(m.b);			// after calling constructor--> object 'm' load variable b = 60
		
		
	}
}
