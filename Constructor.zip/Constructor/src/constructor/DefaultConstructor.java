package constructor;

public class DefaultConstructor {
		
		public DefaultConstructor ()		// We can't see declearation of DefaultConstructor
		//it's virtual and it is look like this
		{

		}

		public static void main(String[] args) {

			DefaultConstructor x = new DefaultConstructor();// We can't see DefaultConstructor
															// but we can use it 
															//Without Constructor there is no class in java
// Default Constructor is always public and zero argument
}

}
