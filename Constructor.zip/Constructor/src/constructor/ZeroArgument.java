package constructor;

public class ZeroArgument {
	
	ZeroArgument()
	{
		System.out.println("This is Zero Argument Constructor");	
	}
	
	public static void main(String[] args) 
	{
	
		new ZeroArgument();
	}

}
