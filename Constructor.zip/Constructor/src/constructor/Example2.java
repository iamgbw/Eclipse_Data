package constructor;

public class Example2 {
	
	static int a = 10;
		   int b ;
		   
		   Example2 ()
		   {
			   a = 30;
			   b = 40;
		   }

		  Example2 (int s)
		   {
			   a = 50;
			   b = 60;
		   }
		   
		   public static void main( String[] args) 
		   {
			 
			   System.out.println(a);				// ----> o/p  => 10
			   System.out.println(Example2.a);		// ----> o/p  => 10
			   
			   Example2 n = new Example2();
			   System.out.println(a);				// ----> o/p  => 30		
			   System.out.println(n.b);				// ----> o/p  => 40
			   
			   int c = a + (n.b);		
			   System.out.println(c);				// ----> o/p  => 70
			   
			   
			   Example2 m = new Example2(15);
			   System.out.println(a);				// ----> o/p  => 50		
			   System.out.println(m.b);				// ----> o/p  => 60
			   
			   int v = a + (m.b);		
			   System.out.println(v);				// ----> o/p  => 110
			   
			   int w = (n.b) + (m.b) ;
			   System.out.println(w);				// ----> o/p => 100
			   
			   int x = (n.b) * (m.b) ;
			   System.out.println(x);
			   
			   System.out.println(n.a);
			   System.out.println(m.a);
			   System.out.println(a);
			   int e = ((n.a) * (m.a)) + (Example2.a);
			   System.out.println(e);
		   }
}
