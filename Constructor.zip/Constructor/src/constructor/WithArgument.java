package constructor;

public class WithArgument 
{
	WithArgument()
	{
		System.out.println("This is Zero Argument Constructor");
	}
	
	WithArgument(char d)
	{
		System.out.println("This is One Argument Constructor");
	}
	
	WithArgument(char f , int r )
	{
		System.out.println("This is Two Argument Constructor");
	}
	
	WithArgument(char f , int r, String s ){
		System.out.println("This is Three Argument Constructor");
	}
	
	public static void main(String[] args) {
		new WithArgument();
		//System.out.println();
		
		new WithArgument('@');
		//System.out.println();
		
		new WithArgument('$' , 24);
		//System.out.println();
		
		new WithArgument('#', 47, "Ram");
		//System.out.println();
		
		int g = '@';			// ASCII Code
		System.out.println(g);	// ASCII Code  '@ = 64' in Decimal
	}
}
