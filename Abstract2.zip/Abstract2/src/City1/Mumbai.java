package City1;

public abstract class Mumbai extends Delhi {
	public void beta() 
	{
		System.out.println("Beta");
	}
}
