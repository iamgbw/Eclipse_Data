package City1;

public abstract class Delhi {
	
	public static void demo () 
	{
		System.out.println("static method");
	}
	
	public void test ()
	{
		System.out.println("Non Static Method");
	}
	
	public abstract void alpha ();
	public abstract void beta ();

}
