package City2;

import City1.Mumbai;

public class Hyderadab extends Mumbai 
{
	public void alpha() 
	{
		System.out.println("Alpha");
	}
}
