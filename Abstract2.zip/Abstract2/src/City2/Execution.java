package City2;

import City1.Delhi;
import City1.Mumbai;

public class Execution {
	public static void main(String[] args) {
		
		Delhi.demo();
		Mumbai.demo();
		Hyderadab.demo();
		
//		Delhi d = new Delhi ();
//		Mumbai m = new Mumbai ();
		Hyderadab h = new Hyderadab ();
		h.alpha();
		h.beta();
		h.test();
	}
}
