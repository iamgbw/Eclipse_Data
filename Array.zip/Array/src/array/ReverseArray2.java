package array;

public class ReverseArray2 {
	
	public static void main(String[] args) {
		
		 int a [] = { 12, 81, 2, 15, 25, 36, 48 }; // array initialization and Decleration

		 int size = a.length ;
			
		 System.out.println(size); // array size = 7
			
		 System.out.println("------------");
		 
		 for(int i = 0 ; i < size ; i++) //This for loop is used to print array in sequence
			{
				System.out.print( a[i] + "," );
			}
		
		 System.out.println();

		 int g;
		 
		 for (int i = 0; i < (size-1) ; i++)
		 {	 
			 for (int j = (size-1) ; j > 0 ; j--)
			 {
				g    = a[i];
				a[i] = a[j];
				a[j] = g;++
			 }
		 }
		 
		 System.out.println("------------");

		for(int i = 0 ; i < size ; i++) //This for loop is used to print array in sequence
		{
			System.out.print( a[i] +  ",");
			System.out.println(i);
		}
		 
	}

}
