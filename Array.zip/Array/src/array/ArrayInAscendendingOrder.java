package array;

public class ArrayInAscendendingOrder {

	public static void main(String[] args) {

		int a [] = {12,47,56,14,32};
		
		int size = a.length;
		int temp;
		
		System.out.println(size);
		
		System.out.println("----------------------");
		
		// Display array in original sequence
		System.out.println("Display array in original sequence");
		for (int i = 0; i < size ; i++)
		{
			System.out.print(a[i] + " ");
		}
		System.out.println();
		System.out.println("----------------------");
		
		// Program for array in Ascending order
		for (int i = 0; i < size; i++) 
		{     
            for (int j = i+1; j < size; j++) 
            {     
               if(a[i] > a[j]) 
               {    
                   temp = a[i];    
                   a[i] = a[j];    
                   a[j] = temp;    
               }     
            }     

		}
		
		//System.out.println("----------------------");
		
		// Display array in Sorted Ascending sequence
		System.out.println("Display array in Sorted Ascending sequence");
		for (int i = 0; i < size ; i++)
		{
			System.out.print(a[i] + " ");
		}
		
		System.out.println();
		System.out.println("----------------------");
		
		// Program for array in Descending order
		for (int i = 0; i < size; i++) 
		{     
            for (int j = i+1; j < size; j++) 
            {     
               if(a[i] < a[j]) 
               {    
                   temp = a[i];    
                   a[i] = a[j];    
                   a[j] = temp;    
               }     
            }     

		}
		
		//System.out.println("----------------------");
		
		// Display array in Sorted sequence
		System.out.println("Display array in Sorted Descending sequence");
		for (int i = 0; i < size ; i++)
		{
			System.out.print(a[i] + " ");
		}
	}

}
