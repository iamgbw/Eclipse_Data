package array;

public class Array {
	
	public static void main(String[] args) {
		
		int a [] = {12,47,56,14,32};
		
		int [] b = {45,23,15,65,75};
		
		int c [] = new int [4];
		char [] d = new char [3];
		
		c[1] = 14;
		c[3] = 85;
		//c[4] = 97;
		
		System.out.println(c[1]);
		System.out.println(c[3]);
		System.out.println(c[0]);
		//System.out.println(c[4]);
		
		
		System.out.println(a[4]);
		System.out.println(b[2]);
		
		a[2] = 100;
		System.out.println(a[2]);
		
		System.out.println(d[1]);
		d[1] = 'G';
		System.out.println(d[1]);
		
	}

}
