package array;

public class Example1 {
	
	public static void main(String[] args) {
		
		int a [] = {12,47,56,14,32};
		
		int size = a.length;
		
		System.out.println(size);
		
		System.out.println();
		
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
		System.out.println(a[4]);
		
		System.out.println("-------");
		
		for (int i = 0 ; i < size; i++)
		{
			System.out.println(a[i]);
		}
		
		System.out.println("--------");
		
		for (int i = (size - 1) ; i >= 0; i--)  // print array in reverse order
		{
			System.out.println(a[i]);
		}
	}
}
