package array;

public class SwapLogic {
	
	public static void main(String[] args) {
		
		int x = 12;
		int y = 15;
		System.out.println(x);
		System.out.println(y);
		
		int z = x;
		x = y;
		y = z;
		System.out.println(x);
		System.out.println(y);
		
	}

}
