package array;

public class ReverseArray {

	
	public static void main(String[] args) {
		
		 int a [] = { 12, 81, 2, 15, 25, 36, 48 }; // array initialization and Decleration

		int size = a.length ;
		
		System.out.println(size); // array size = 7
		
		System.out.println("------------");
		
		for(int i = 0 ; i < size ; i++) //This for loop is used to print array in sequence
		{
			System.out.print( a[i] );
			System.out.print(",");
		}
		
		System.out.println();
		System.out.println("------------");
		
		int n; // line no 25 to 38 we reverse the array

		n    = a[0];
		a[0] = a[6];
		a[6] = n;
		
		n    = a[1];
		a[1] = a[5];
		a[5] = n;
		
		n    = a[2];
		a[2] = a[4];
		a[4] = n;
		
		
		
		for(int i = 0 ; i < size ; i++) //This for loop is used to print *reversed* array in sequence
		{
			System.out.print( a[i] );
			System.out.print(",");
		}
		
		System.out.println();
		System.out.println("------------");
		
		
		
		for (int i = (size-1) ; i >= 0 ; i--) // This for loop is used to print array in reverse order
		{
			n = a[i];
			
			System.out.print(n);
			System.out.print(",");				
		}
		
		System.out.println();
		System.out.println("------------");
		
		System.out.println( a[4] );
		
//		int g;
//		
//		for(int i = 0 ; i < size ; i++)
//		{
//			g = a[i];
//			
//			for (int j = (size-1); j > 0 ; j--)
//			{
//				a[i] = a[j];
//				a[j] = g ;
//				System.out.print( a[i] );
//				System.out.print(",");
//				
//			}
//			
//		}
//		System.out.println();
//		System.out.println( a[4] );

	}
}
